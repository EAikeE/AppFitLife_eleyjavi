import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.kotlinAndroid)
    alias(libs.plugins.kotlinComposeCompiler)
    alias(libs.plugins.ksp) // This is the correct way to apply it.
    id("jacoco")
}

// Lee las propiedades del keystore
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.appfitlife.appfitlife"
    compileSdk = 34

    signingConfigs {
        create("release") {
            if (keystorePropertiesFile.exists()) {
                storeFile = file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
            }
        }
    }

    defaultConfig {
        applicationId = "com.appfitlife.appfitlife"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1,LICENSE.md,LICENSE-notice.md}"
        }
    }
    
    // Configuración para usar JUnit 5
    testOptions {
        unitTests.all {
            it.useJUnitPlatform()
        }
    }
}

// REEMPLAZA TU BLOQUE 'dependencies' CON ESTE
dependencies {
    // --- Variables de Versiones ---
    val room_version = "2.6.1"

    // --- Android Core & UI ---
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation("androidx.compose.material:material-icons-extended:1.6.5")
    implementation("io.coil-kt:coil-compose:2.5.0") // Para cargar imágenes

    // --- Navegación ---
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // --- ViewModel & LiveData ---
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.0")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")

    // --- Room (Base de datos local) ---
    implementation("androidx.room:room-runtime:$room_version")
    implementation("androidx.room:room-ktx:$room_version")
    ksp("androidx.room:room-compiler:$room_version")

    // --- Retrofit (Llamadas a la API de Red) ---
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    // --- Pruebas Unitarias ---
    testImplementation(libs.junit)
    testImplementation("io.kotest:kotest-runner-junit5:5.8.0")
    testImplementation("io.kotest:kotest-assertions-core:5.8.0")
    testImplementation("io.mockk:mockk:1.13.8")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")

    // --- Pruebas de Instrumentación (UI) ---
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation("io.mockk:mockk-android:1.13.8")

    // --- Dependencias de Debug ---
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}



// Configuración de la versión de JaCoCo
jacoco {
    toolVersion = "0.8.11" // Versión actual y estable de JaCoCo
}

// Tarea personalizada para generar el reporte de cobertura de las pruebas unitarias
tasks.register("jacocoTestReport", JacocoReport::class) {
    // Esta tarea depende de que las pruebas unitarias del tipo 'debug' se hayan ejecutado
    dependsOn("testDebugUnitTest")

    // Define los formatos de reporte que se generarán
    reports {
        xml.required.set(true)
        html.required.set(true) // El reporte HTML es el que abrirás en el navegador
    }

    // Filtros para excluir archivos generados automáticamente del reporte
    val fileFilter = listOf(
        "**/R.class", "**/R$*.class", "**/BuildConfig.*", "**/Manifest*.*",
        "**/*Test*.*", "android/databinding/**/*.class", "**/*_Impl*.*",
        "**/*\$ViewInjector*.*", "**/*\$ViewBinder*.*", "**/Lambda$*.class",
        "**/*\$inlined$*.class", "**/*\$DefaultImpls*.*",
        // Excluir clases generadas por Room y KSP
        "**/*_Impl.class", "**/generated/ksp/**/*"
    )

    // Directorio de las clases compiladas de Kotlin para el build 'debug'
    val debugTree = fileTree("${buildDir}/tmp/kotlin-classes/debug") {
        exclude(fileFilter)
    }

    // Directorio principal del código fuente
    val mainSrc = "${project.projectDir}/src/main/java"

    sourceDirectories.setFrom(files(mainSrc))
    classDirectories.setFrom(files(debugTree))

    // Ubicación de los resultados de la ejecución de las pruebas
    executionData.setFrom(fileTree(buildDir) {
        include("outputs/unit_test_code_coverage/debugUnitTest/testDebugUnitTest.exec")
    })
}
