package com.appfitlife.appfitlife.ui.screens.auth

import android.util.Patterns
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.appfitlife.appfitlife.data.AuthResult
import com.appfitlife.appfitlife.ui.screens.PasswordTextField
import com.appfitlife.appfitlife.viewmodel.AuthViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(navController: NavController, viewModel: AuthViewModel, onLoginSuccess: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var genderError by remember { mutableStateOf<String?>(null) }
    var weightError by remember { mutableStateOf<String?>(null) }
    var heightError by remember { mutableStateOf<String?>(null) }
    var ageError by remember { mutableStateOf<String?>(null) }

    var genderMenuExpanded by remember { mutableStateOf(false) }
    val genderOptions = listOf("Masculino", "Femenino", "Otro")

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val authResult by viewModel.authResult.collectAsState(initial = null)

    LaunchedEffect(authResult) {
        when (val result = authResult) {
            is AuthResult.Success -> {
                onLoginSuccess()
                viewModel.clearAuthResult() // Limpia el resultado para no volver a navegar
            }
            is AuthResult.Failure -> {
                nameError = result.message
                viewModel.clearAuthResult()
            }
            else -> {}
        }
    }

    fun validateFields(): Boolean {
        nameError = if (name.isBlank()) "El nombre es obligatorio" else null
        emailError = if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) "Email inválido" else null
        passwordError = if (password.length < 6) "Mínimo 6 caracteres" else null
        genderError = if (gender.isBlank()) "Debes seleccionar un género" else null
        weightError = if (weight.toDoubleOrNull() == null) "Debe ser un número" else null
        heightError = if (height.toDoubleOrNull() == null) "Debe ser un número" else null
        ageError = if (age.toIntOrNull() == null) "Debe ser un número" else null
        return nameError == null && emailError == null && passwordError == null && genderError == null && weightError == null && heightError == null && ageError == null
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(it).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Text("Crear Cuenta", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre de usuario") }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = nameError != null, supportingText = { nameError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = emailError != null, supportingText = { emailError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                PasswordTextField(value = password, onValueChange = { password = it }, label = "Contraseña", modifier = Modifier.fillMaxWidth(), isError = passwordError != null, supportingText = { passwordError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                ExposedDropdownMenuBox(
                    expanded = genderMenuExpanded,
                    onExpandedChange = { genderMenuExpanded = !genderMenuExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = gender,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Sexo") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = genderMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        isError = genderError != null,
                        supportingText = { genderError?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
                    )
                    ExposedDropdownMenu(
                        expanded = genderMenuExpanded,
                        onDismissRequest = { genderMenuExpanded = false }
                    ) {
                        genderOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    gender = option
                                    genderMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Peso (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = weightError != null, supportingText = { weightError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Altura (cm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = heightError != null, supportingText = { heightError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Edad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = ageError != null, supportingText = { ageError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(24.dp))

                Button(onClick = {
                    if (validateFields()) {
                        viewModel.register(name, email, password, age, weight, height)
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Faltan campos por completar o son incorrectos") }
                    }
                }) {
                    Text("Registrarse")
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = { navController.navigate("login") }) {
                    Text("¿Ya tienes cuenta? Inicia Sesión")
                }
            }
        }
    }
}