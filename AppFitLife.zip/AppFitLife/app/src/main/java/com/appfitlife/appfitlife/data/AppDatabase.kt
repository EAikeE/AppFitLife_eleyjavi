package com.appfitlife.appfitlife.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.appfitlife.appfitlife.domain.getPredefinedExercises
import com.appfitlife.appfitlife.domain.getPredefinedFoodItems
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [User::class, RoutineEntity::class, Exercise::class, RoutineExerciseCrossRef::class, MealPlanEntity::class, FoodItem::class, MealPlanFoodCrossRef::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun routineDao(): RoutineDao
    abstract fun mealPlanDao(): MealPlanDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "appfitlife_database"
                )
                .addCallback(DatabaseCallback(context)) // Add the callback to populate the DB
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    // This callback is triggered when the database is created for the first time.
    private class DatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // This coroutine will execute after the database has been created.
            CoroutineScope(Dispatchers.IO).launch {
                // Get the database instance and populate it with the catalog data.
                getDatabase(context).let { database ->
                    val routineDao = database.routineDao()
                    val mealPlanDao = database.mealPlanDao()

                    // Insert the predefined exercises and foods from your PlanGenerator
                    routineDao.insertAllExercises(getPredefinedExercises())
                    mealPlanDao.insertAllFoodItems(getPredefinedFoodItems())
                }
            }
        }
    }
}