package com.appfitlife.appfitlife.data

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Failure(val message: String) : AuthResult()
    object LoggedOut : AuthResult()
}

data class BmiResult(
    val value: Float,
    val category: String,
    val weightGoalMsg: String
)

data class RecommendedPlans(
    val recommendedRoutine: RoutineWithExercises?,
    val recommendedMealPlan: MealPlanWithFoods?
)
