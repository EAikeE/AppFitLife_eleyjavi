package com.appfitlife.appfitlife.data

import android.util.Log
import com.appfitlife.appfitlife.network.ApiService
import com.appfitlife.appfitlife.network.RetrofitClient
import kotlinx.coroutines.flow.Flow

class UserRepository(private val userDao: UserDao) {

    private val apiService: ApiService = RetrofitClient.instance

    suspend fun getUserByName(name: String): User? {
        if (name.isBlank()) {
            Log.d("UserRepository", "Búsqueda cancelada: el nombre de usuario está vacío.")
            return null
        }
        return try {
            val allUsers = apiService.getUsers()
            val foundUser = allUsers.find { it.name.equals(name, ignoreCase = true) }
            Log.d("UserRepository", "Buscando por nombre '$name'. Encontrado: $foundUser")
            foundUser
        } catch (e: Exception) {
            Log.e("UserRepository", "Error al obtener usuarios por nombre: ${e.message}")
            null
        }
    }

    suspend fun insertUser(user: User): User {
        return try {
            val createdUser = apiService.createUser(user)
            Log.d("UserRepository", "Usuario creado en el servidor: $createdUser")
            userDao.insertUser(createdUser)
            createdUser
        } catch (e: Exception) {
            Log.e("UserRepository", "Error al insertar usuario: ${e.message}")
            throw e
        }
    }

    suspend fun getUserById(id: String): User? {
        return try {
            val user = apiService.getUserById(id)
            user?.let { userDao.insertUser(it) } // Actualiza la BD local
            user
        } catch (e: Exception) {
            Log.e("UserRepository", "Error al obtener usuario por ID: ${e.message}")
            userDao.getUserById(id) // Intenta obtener de la BD local si falla la red
        }
    }

    fun getUserByIdFlow(id: String): Flow<User?> {
        return userDao.getUserByIdFlow(id)
    }

    suspend fun updateUser(user: User) {
        try {
            apiService.updateUser(user.id, user)
            userDao.updateUser(user) // Actualiza también la BD local
        } catch (e: Exception) {
            Log.e("UserRepository", "Error al actualizar usuario: ${e.message}")
            // Opcional: manejar el error, tal vez reintentar o notificar al usuario
        }
    }
}
