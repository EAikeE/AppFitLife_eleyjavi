package com.appfitlife.appfitlife.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.appfitlife.appfitlife.data.User

@Composable
fun ExcludedFoodsDialog(currentExcluded: List<String>, onDismiss: () -> Unit, onConfirm: (List<String>) -> Unit) {
    var text by remember { mutableStateOf("") }
    val excluded = remember { mutableStateListOf<String>().also { it.addAll(currentExcluded) } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Gestionar Alimentos Excluidos") },
        text = {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Añadir alimento") }, modifier = Modifier.weight(1.0f))
                    IconButton(onClick = { if (text.isNotBlank()) { excluded.add(text); text = "" } }) {
                        Icon(Icons.Default.AddCircle, "Añadir")
                    }
                }
                Spacer(Modifier.height(16.dp))
                LazyColumn {
                    items(excluded) { food ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(food, modifier = Modifier.weight(1f))
                            IconButton(onClick = { excluded.remove(food) }) {
                                Icon(Icons.Default.RemoveCircle, "Quitar")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onConfirm(excluded.toList()) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun EditNameDialog(user: User, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var newUsername by remember { mutableStateOf(user.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cambiar nombre") },
        text = { OutlinedTextField(value = newUsername, onValueChange = { newUsername = it }, label = { Text("Nuevo nombre de usuario") }) },
        confirmButton = { Button(onClick = { onConfirm(newUsername) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun SetGoalDialog(targetWeight: String, onTargetWeightChange: (String) -> Unit, onDismiss: () -> Unit, onConfirm: () -> Unit, goalDate: String?) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Establecer Meta de Peso") },
        text = {
            Column {
                OutlinedTextField(value = targetWeight, onValueChange = onTargetWeightChange, label = { Text("Peso deseado (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                goalDate?.let {
                    Spacer(Modifier.height(16.dp))
                    Text(it, style = MaterialTheme.typography.bodyLarge)
                }
            }
        },
        confirmButton = { Button(onClick = onConfirm) { Text("Generar Plan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}