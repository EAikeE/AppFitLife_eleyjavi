package com.appfitlife.appfitlife.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.appfitlife.appfitlife.data.*
import com.appfitlife.appfitlife.data.generateWeeklyPlan // Correct import
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.pow

// --- UI-specific data classes for a cleaner state ---

// Represents a single exercise with its details for the UI
data class UiRoutineExercise(
    val name: String,
    val details: String
)

// Represents a full routine (e.g., for one day) for the UI
data class UiRoutine(
    val name: String,
    val exercises: List<UiRoutineExercise>
)

// Represents a single food item with its details for the UI
data class UiMealFood(
    val name: String,
    val details: String,
    val calories: Int
)

// Represents a full meal plan (e.g., for one meal type) for the UI
data class UiMealPlan(
    val name: String,
    val foods: List<UiMealFood>
)

// Represents the complete state for the user's profile screen
data class UserProfileState(
    val user: User? = null,
    val routines: List<UiRoutine> = emptyList(),
    val mealPlans: List<UiMealPlan> = emptyList(),
    val initialSetupDone: Boolean = false
)

class ProfileViewModel(
    private val userRepository: UserRepository,
    private val routineDao: RoutineDao,
    private val mealPlanDao: MealPlanDao,
    application: Application
) : AndroidViewModel(application) {

    private val _userId = MutableStateFlow<String?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val userProfile: StateFlow<UserProfileState> = _userId.flatMapLatest { userId ->
        if (userId == null) {
            flowOf(UserProfileState()) // Emit default state if no user
        } else {
            combine(
                userRepository.getUserByIdFlow(userId),
                routineDao.getRoutinesForUser(userId),
                mealPlanDao.getMealPlansForUser(userId)
            ) { user, dbRoutines, dbMealPlans ->

                // Map database routines to UI-friendly routines
                val uiRoutines = dbRoutines.map { routineData ->
                    val detailsMap = routineData.details.associateBy { it.exerciseId }
                    val uiExercises = routineData.exercises.map { exercise ->
                        UiRoutineExercise(
                            name = exercise.name,
                            details = detailsMap[exercise.exerciseId]?.quantity ?: ""
                        )
                    }
                    UiRoutine(name = routineData.routine.name, exercises = uiExercises)
                }

                // Map database meal plans to UI-friendly meal plans
                val uiMealPlans = dbMealPlans.map { mealPlanData ->
                    val detailsMap = mealPlanData.details.associateBy { it.foodItemId }
                    val uiFoods = mealPlanData.foods.map { food ->
                        UiMealFood(
                            name = food.name,
                            details = detailsMap[food.foodItemId]?.detail ?: "",
                            calories = food.calories
                        )
                    }
                    UiMealPlan(name = mealPlanData.mealPlan.name, foods = uiFoods)
                }

                UserProfileState(user, uiRoutines, uiMealPlans, initialSetupDone = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfileState())

    fun setUserId(userId: String) {
        _userId.value = userId
        viewModelScope.launch {
            try {
                userRepository.getUserById(userId)
            } catch (e: Exception) {
                // Optionally handle network errors
            }
        }
    }

    fun calculateWeightGoalDate(currentWeight: Float, targetWeight: Float): String {
        if (currentWeight <= 0 || targetWeight <= 0) return ""
        val diff = kotlin.math.abs(currentWeight - targetWeight)
        if (diff < 0.5) return "Ya estás en tu peso objetivo."
        val weeks = kotlin.math.ceil(diff / 0.5).toInt()
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.WEEK_OF_YEAR, weeks)
        val date = calendar.time
        val formattedDate = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(date)
        
        val months = weeks / 4
        val remainingWeeks = weeks % 4
        val timeString = when {
            months > 0 && remainingWeeks > 0 -> "$months meses y $remainingWeeks semanas"
            months > 0 -> "$months meses"
            else -> "$weeks semanas"
        }
        
        return "Fecha estimada: $formattedDate (aprox. $timeString)."
    }

    fun setWeightGoalAndGeneratePlan(user: User, targetWeightKg: Float): String {
        val currentWeight = user.weight?.toFloat() ?: 0f
        if (currentWeight <= 0 || targetWeightKg <= 0) return "Por favor, introduce un peso válido."

        val goal = if (targetWeightKg < currentWeight) "loss" else "gain"

        viewModelScope.launch {
            val updatedUser = user.copy(targetWeight = targetWeightKg.toDouble())
            userRepository.updateUser(updatedUser)

            routineDao.deleteRoutinesForUser(user.id)
            mealPlanDao.deleteMealPlansForUser(user.id)
            
            // Call the function from the data layer
            generateWeeklyPlan(goal, user.id, updatedUser.excludedFoods ?: emptyList(), routineDao, mealPlanDao)
        }

        return ("¡Plan semanal generado para alcanzar %.1f kg!").format(targetWeightKg)
    }

    fun updateUserName(newName: String) {
        userProfile.value.user?.let {
            val updatedUser = it.copy(name = newName)
            viewModelScope.launch { userRepository.updateUser(updatedUser) }
        }
    }

    fun updateUserImage(imageUri: Uri) {
        userProfile.value.user?.let {
            val updatedUser = it.copy(imageUri = imageUri.toString())
            viewModelScope.launch { userRepository.updateUser(updatedUser) }
        }
    }

    fun updateUserExcludedFoods(excludedFoods: List<String>) {
        val currentUser = userProfile.value.user ?: return
        val updatedUser = currentUser.copy(excludedFoods = excludedFoods)

        viewModelScope.launch {
            userRepository.updateUser(updatedUser)
            updatedUser.targetWeight?.let { weight ->
                val goal = if (weight.toFloat() < (updatedUser.weight ?: 0.0)) "loss" else "gain"
                routineDao.deleteRoutinesForUser(updatedUser.id)
                mealPlanDao.deleteMealPlansForUser(updatedUser.id)
                generateWeeklyPlan(goal, updatedUser.id, updatedUser.excludedFoods ?: emptyList(), routineDao, mealPlanDao)
            }
        }
    }
    fun calculateBmiAndWeightGoal(weightKg: Float, heightCm: Float): BmiResult {
        if (heightCm <= 0 || weightKg <= 0) return BmiResult(0f, "Datos inválidos", "Por favor, asegúrate de que tu peso y altura sean correctos en tu perfil.")
        val heightM = heightCm / 100f
        val bmi = weightKg / (heightM * heightM)
        val category = when {
            bmi < 18.5 -> "Bajo peso"
            bmi < 25 -> "Peso saludable"
            bmi < 30 -> "Sobrepeso"
            else -> "Obesidad"
        }
        val idealMin = 18.5f * heightM.pow(2)
        val idealMax = 24.9f * heightM.pow(2)
        val goalMsg = when (category) {
            "Peso saludable" -> "¡Felicidades! Estás en tu peso ideal (entre %.1f kg y %.1f kg). Puedes enfocarte en mantener tu estilo de vida o tonificar.".format(idealMin, idealMax)
            "Bajo peso" -> "Tu IMC indica bajo peso. Tu rango de peso ideal está entre %.1f kg y %.1f kg. ¡Un plan de superávit calórico y fuerza te ayudará a ganar peso de forma saludable!".format(idealMin, idealMax)
            else -> "Tu IMC indica sobrepeso. Tu rango de peso ideal está entre %.1f kg y %.1f kg. Un buen primer objetivo sería llegar a %.1f kg.".format(idealMin, idealMax, idealMax)
        }
        return BmiResult(bmi, category, goalMsg)
    }
}
