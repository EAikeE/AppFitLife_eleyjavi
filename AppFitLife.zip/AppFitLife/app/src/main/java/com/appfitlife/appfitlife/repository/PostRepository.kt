package com.appfitlife.appfitlife.repository

import com.appfitlife.appfitlife.data.model.Post
import com.appfitlife.appfitlife.data.remote.RetrofitInstance

open class PostRepository {
    private val apiService = RetrofitInstance.api

    open suspend fun getPosts(): List<Post> {
        return apiService.getPosts()
    }
}