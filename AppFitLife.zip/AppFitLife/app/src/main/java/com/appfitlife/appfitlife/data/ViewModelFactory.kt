package com.appfitlife.appfitlife.data

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.appfitlife.appfitlife.viewmodel.AuthViewModel
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

class ViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val db = AppDatabase.getDatabase(application)
        val userRepository = UserRepository(db.userDao())

        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(userRepository) as T
        }
        if (modelClass.isAssignableFrom(ProfileViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProfileViewModel(userRepository, db.routineDao(), db.mealPlanDao(), application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}