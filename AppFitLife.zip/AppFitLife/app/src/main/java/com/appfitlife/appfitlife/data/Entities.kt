package com.appfitlife.appfitlife.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey
    var id: String,var name: String,
    var email: String,
    var password: String,
    var age: Int,
    var weight: Double,
    var height: Double,
    val imageUri: String?,
    val gender: String?,
    val excludedFoods: List<String>? = null,
    val targetWeight: Double? = null
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true)
    val routineId: Long = 0,
    val name: String,
    val userId: String
)

@Entity(tableName = "meal_plans")
data class MealPlanEntity(
    @PrimaryKey(autoGenerate = true)
    val mealPlanId: Long = 0,
    val name: String,
    val userId: String
)

@Entity(
    tableName = "routine_exercise_cross_ref",
    primaryKeys = ["routineId", "exerciseId"],
    indices = [Index(value = ["exerciseId"])]
)
data class RoutineExerciseCrossRef(
    val routineId: Long,
    val exerciseId: Long,
    val quantity: String? = null
)

@Entity(
    tableName = "meal_plan_food_cross_ref",
    primaryKeys = ["mealPlanId", "foodItemId"],
    indices = [Index(value = ["foodItemId"])]
)
data class MealPlanFoodCrossRef(
    val mealPlanId: Long,
    val foodItemId: Long,
    val detail: String? = null
)

@Entity(tableName = "exercise_table")
data class Exercise(
    @PrimaryKey(autoGenerate = true)
    val exerciseId: Long = 0,
    val name: String,
    val description: String,
    val sets: String?,
    val reps: String?
)

@Entity(tableName = "food_item_table")
data class FoodItem(
    @PrimaryKey(autoGenerate = true)
    val foodItemId: Long = 0,
    val name: String,
    val calories: Int
)
