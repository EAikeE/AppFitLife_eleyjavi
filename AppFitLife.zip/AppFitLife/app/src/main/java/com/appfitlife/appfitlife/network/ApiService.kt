package com.appfitlife.appfitlife.network

import com.appfitlife.appfitlife.data.User
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    // READ ALL: Obtiene todos los usuarios (para el login por nombre)
    @GET("users")
    suspend fun getUsers(): List<User>

    // READ: Obtiene un usuario por su ID
    @GET("users/{id}")
    suspend fun getUserById(@Path("id") userId: String): User?

    // CREATE: Crea un nuevo usuario
    @POST("users")
    suspend fun createUser(@Body user: User): User

    // UPDATE: Actualiza un usuario existente
    @PUT("users/{id}")
    suspend fun updateUser(@Path("id") userId: String, @Body user: User): User

    // DELETE: Borra un usuario
    @DELETE("users/{id}")
    suspend fun deleteUser(@Path("id") userId: String): Response<Void>
}
