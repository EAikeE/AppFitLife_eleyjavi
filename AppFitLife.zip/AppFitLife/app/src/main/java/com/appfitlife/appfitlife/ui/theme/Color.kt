package com.appfitlife.appfitlife.ui.theme

import androidx.compose.ui.graphics.Color

// -- PALETA DE COLORES PROFESIONAL Y ATRACTIVA --

// Colores primarios y acentos
val Primary = Color(0xFF00C853) // Un verde más vibrante y enérgico
val PrimaryVariant = Color(0xFF009624) // Un tono más oscuro para variantes
val Secondary = Color(0xFFFFAB00) // Un ámbar intenso para acentos
val SecondaryVariant = Color(0xFFFF8F00) // Un ámbar más oscuro
val Accent = Color(0xFF40C4FF) // Azul claro para elementos de acento (como FABs o iconos)

// Colores de fondo y superficie
val Background = Color(0xFFF7F9FC) // Un fondo muy claro y limpio
val Surface = Color(0xFFFFFFFF) // Blanco para tarjetas y superficies principales
val SurfaceVariant = Color(0xFFF2F2F7) // Un gris muy claro para fondos sutiles

// Colores de texto
val OnPrimary = Color.White
val OnSecondary = Color.Black
val OnBackground = Color(0xFF1C1C1E) // Texto principal, casi negro para mejor legibilidad
val OnSurface = Color(0xFF1C1C1E)
val OnSurfaceVariant = Color(0xFF6E6E73) // Texto secundario, más suave

// Colores funcionales
val Error = Color(0xFFFF3B30) // Rojo estándar de iOS para errores, muy visible
val Success = Color(0xFF34C759) // Verde para mensajes de éxito
val Warning = Color(0xFFFF9500) // Naranja para advertencias

// Colores para gradientes (pueden ser usados en tarjetas o fondos)
val GradientStart = Color(0xFF00C853)
val GradientEnd = Color(0xFF40C4FF)
