package com.appfitlife.appfitlife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appfitlife.appfitlife.data.AuthResult
import com.appfitlife.appfitlife.data.User
import com.appfitlife.appfitlife.data.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(private val userRepository: UserRepository) : ViewModel() {
    private val _authResult = MutableStateFlow<AuthResult?>(null)
    val authResult: StateFlow<AuthResult?> = _authResult.asStateFlow()

    private val _loggedInUserId = MutableStateFlow<String?>(null)
    val loggedInUserId: StateFlow<String?> = _loggedInUserId.asStateFlow()

    fun login(name: String, password: String) {
        if (name.isBlank() || password.isBlank()) {
            _authResult.value = AuthResult.Failure("El nombre y la contraseña no pueden estar vacíos.")
            return
        }

        viewModelScope.launch {
            val user = userRepository.getUserByName(name)
            if (user != null && user.password == password) {
                _loggedInUserId.value = user.id
                _authResult.value = AuthResult.Success(user)
            } else {
                _authResult.value = AuthResult.Failure("Usuario no encontrado o contraseña incorrecta.")
            }
        }
    }

    fun register(name: String, email: String, password: String, ageStr: String, weightStr: String, heightStr: String) {
        viewModelScope.launch {
            if (userRepository.getUserByName(name) != null) {
                _authResult.value = AuthResult.Failure("El nombre de usuario ya existe.")
                return@launch
            }

            val newUser = User(
                id = "temp_id",
                name = name,
                email = email,
                password = password,
                age = ageStr.toIntOrNull() ?: 0,
                weight = weightStr.toDoubleOrNull() ?: 0.0,
                height = heightStr.toDoubleOrNull() ?: 0.0,
                imageUri = "",
                gender = ""
            )

            try {
                val createdUser = userRepository.insertUser(newUser)
                _loggedInUserId.value = createdUser.id
                _authResult.value = AuthResult.Success(createdUser)
            } catch (e: Exception) {
                _authResult.value = AuthResult.Failure("Error en el registro: ${e.message}")
            }
        }
    }

    fun logout() {
        _loggedInUserId.value = null
        _authResult.value = AuthResult.LoggedOut
    }

    fun clearAuthResult() {
        _authResult.value = null
    }
}
