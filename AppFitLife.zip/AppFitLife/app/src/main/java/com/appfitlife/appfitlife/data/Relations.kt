package com.appfitlife.appfitlife.data

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

// Representa una rutina completa, incluyendo la lista de ejercicios y los detalles de cada uno.
data class RoutineWithExercises(
    @Embedded
    val routine: RoutineEntity,

    // Esta relación obtiene la lista de todos los Ejercicios vinculados a la rutina
    // a través de la tabla RoutineExerciseCrossRef.
    @Relation(
        parentColumn = "routineId",
        entity = Exercise::class,
        entityColumn = "exerciseId",
        associateBy = Junction(RoutineExerciseCrossRef::class)
    )
    val exercises: List<Exercise>,

    // Esta segunda relación es necesaria para obtener los detalles (por ejemplo, la cantidad)
    // de la propia tabla de referencia cruzada.
    @Relation(
        parentColumn = "routineId",
        entityColumn = "routineId",
        entity = RoutineExerciseCrossRef::class
    )
    val details: List<RoutineExerciseCrossRef>
)

// Representa un Plan de Comidas completo, incluyendo la lista de alimentos y los detalles de cada uno.
data class MealPlanWithFoods(
    @Embedded
    val mealPlan: MealPlanEntity,

    // Esta relación obtiene la lista de todos los FoodItems vinculados al plan de comidas
    // a través de la tabla MealPlanFoodCrossRef.
    @Relation(
        parentColumn = "mealPlanId",
        entity = FoodItem::class,
        entityColumn = "foodItemId",
        associateBy = Junction(MealPlanFoodCrossRef::class)
    )
    val foods: List<FoodItem>,

    // Esta segunda relación obtiene los detalles (por ejemplo, la cantidad)
    // de la tabla de referencia cruzada.
    @Relation(
        parentColumn = "mealPlanId",
        entityColumn = "mealPlanId",
        entity = MealPlanFoodCrossRef::class
    )
    val details: List<MealPlanFoodCrossRef>
)
