package com.appfitlife.appfitlife.ui.screens.meals

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.appfitlife.appfitlife.ui.theme.Secondary
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun MyMealPlansScreen(viewModel: ProfileViewModel) {
    val userProfileState by viewModel.userProfile.collectAsState()
    // Cambiado para usar el nuevo `UiMealPlan` que es más simple
    val mealPlans = userProfileState.mealPlans
        .groupBy { it.name.substringBefore(" - ").trim() }
        .toSortedMap(compareBy { day ->
            when (day) {
                "Lunes" -> 1
                "Martes" -> 2
                "Miércoles" -> 3
                "Jueves" -> 4
                "Viernes" -> 5
                "Sábado" -> 6
                "Domingo" -> 7
                else -> 8
            }
        })

    Scaffold(topBar = { TopAppBar(title = { Text("Mis Planes de Comida") }) }) {
        LazyColumn(
            modifier = Modifier.padding(it).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            if (mealPlans.isEmpty() && userProfileState.initialSetupDone) {
                item {
                    Text(
                        "No tienes planes de comida. ¡Establece una meta en tu perfil para empezar!",
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(32.dp)
                    )
                }
            }

            mealPlans.forEach { (day, plansForDay) ->
                stickyHeader {
                    Surface(modifier = Modifier.fillParentMaxWidth(), shadowElevation = 2.dp) {
                        Text(
                            day,
                            style = MaterialTheme.typography.headlineMedium,
                            color = Secondary,
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp)
                        )
                    }
                }

                items(plansForDay) { mealPlan ->
                    Card(modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Usamos `mealPlan.name` directamente
                            Text(mealPlan.name.substringAfter(" - ").trim(), style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            mealPlan.foods.forEach { food ->
                                // Mostramos los detalles y las calorías como querías
                                Text(
                                    "\u2022 ${food.name} (${food.details}) - ${food.calories} kcal",
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}