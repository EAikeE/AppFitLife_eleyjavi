package com.appfitlife.appfitlife

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun RecommendationsScreen(bmi: Float, category: String) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Recomendaciones para ti",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Basado en tu IMC de %.1f (%s)".format(bmi, category),
                style = MaterialTheme.typography.titleMedium
            )
        }

        when {
            category.contains("Sobrepeso") || category.contains("Obesidad") -> {
                item {
                    RecommendationCard(
                        title = "Rutina de Ejercicios Sugerida",
                        icon = Icons.Default.FitnessCenter,
                        content = listOf(
                            "Prioriza el cardio: Realiza al menos 30-45 minutos de cardio (correr, nadar, bicicleta) 4-5 veces por semana.",
                            "Entrenamiento de fuerza: Incorpora 2-3 días de levantamiento de pesas para acelerar tu metabolismo.",
                            "Ejercicios de alta intensidad (HIIT): Son excelentes para quemar grasa en menos tiempo. Intenta hacerlo 1-2 veces por semana."
                        )
                    )
                }
                item {
                    RecommendationCard(
                        title = "Plan de Nutrición Sugerido",
                        icon = Icons.Default.Restaurant,
                        content = listOf(
                            "Déficit calórico: Consume menos calorías de las que quemas. Un déficit de 300-500 kcal al día es un buen punto de partida.",
                            "Proteínas y fibra: Asegúrate de que cada comida contenga una buena fuente de proteínas y fibra para mantenerte lleno.",
                            "Limita los procesados y azúcares: Evita bebidas azucaradas, comida rápida y snacks poco saludables."
                        )
                    )
                }
            }
            category.contains("Bajo peso") -> {
                item {
                    RecommendationCard(
                        title = "Rutina de Ejercicios Sugerida",
                        icon = Icons.Default.FitnessCenter,
                        content = listOf(
                            "Enfócate en la hipertrofia: Levanta pesas de moderadas a pesadas, con 8-12 repeticiones por serie.",
                            "Prioriza los ejercicios compuestos: Sentadillas, peso muerto, press de banca y dominadas son clave para construir masa muscular.",
                            "Descanso adecuado: Duerme al menos 7-8 horas y deja que tus músculos se recuperen entre sesiones."
                        )
                    )
                }
                item {
                    RecommendationCard(
                        title = "Plan de Nutrición Sugerido",
                        icon = Icons.Default.Restaurant,
                        content = listOf(
                            "Superávit calórico: Necesitas consumir más calorías de las que gastas. Un extra de 300-500 kcal es un buen comienzo.",
                            "Alta ingesta de proteínas: Consume entre 1.6 y 2.2 gramos de proteína por kilo de peso corporal para construir músculo.",
                            "Carbohidratos complejos: Arroz integral, avena y patatas te darán la energía que necesitas para tus entrenamientos."
                        )
                    )
                }
            }
            else -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ThumbUp, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                "¡Felicidades! Tu peso es saludable. Sigue manteniendo un estilo de vida activo y una dieta balanceada para conservar tu bienestar.",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecommendationCard(title: String, icon: ImageVector, content: List<String>) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(12.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            content.forEach {
                Text("• $it", modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
            }
        }
    }
}
