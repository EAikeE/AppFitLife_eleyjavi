package com.appfitlife.appfitlife

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.appfitlife.appfitlife.ui.screens.PostScreen
import com.appfitlife.appfitlife.ui.screens.auth.ForgotPasswordScreen
import com.appfitlife.appfitlife.ui.screens.auth.LoginScreen
import com.appfitlife.appfitlife.ui.screens.auth.RegisterScreen
import com.appfitlife.appfitlife.ui.screens.meals.MyMealPlansScreen
import com.appfitlife.appfitlife.ui.screens.profile.ProfileScreen
import com.appfitlife.appfitlife.ui.screens.routines.MyRoutinesScreen
import com.appfitlife.appfitlife.viewmodel.AuthViewModel
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Profile : Screen("profile", "Perfil", Icons.Default.Person)
    object Routines : Screen("routines", "Rutinas", Icons.Default.FitnessCenter)
    object Meals : Screen("meals", "Comidas", Icons.Default.Restaurant)
    object Posts : Screen("posts", "Posts", Icons.AutoMirrored.Filled.List)
}

val bottomNavItems = listOf(
    Screen.Profile,
    Screen.Routines,
    Screen.Meals,
    Screen.Posts
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppFitLifeApp(authViewModel: AuthViewModel, profileViewModel: ProfileViewModel, onUpdateImage: () -> Unit) {
    val navController = rememberNavController()
    val loggedInUserId by authViewModel.loggedInUserId.collectAsState()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val showBottomBar = bottomNavItems.any { it.route == currentDestination?.route }

    val startDestination = if (loggedInUserId != null) Screen.Profile.route else "login"

    val onLoginSuccess = {
        navController.navigate(Screen.Profile.route) {
            popUpTo("login") { inclusive = true }
        }
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = null) },
                            label = { Text(screen.label) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(navController, startDestination = startDestination, Modifier.padding(innerPadding)) {
            composable("login") { LoginScreen(navController, authViewModel, onLoginSuccess) }
            composable("register") { RegisterScreen(navController, authViewModel, onLoginSuccess) }
            composable("forgot_password") { ForgotPasswordScreen(navController, authViewModel) }

            composable(Screen.Profile.route) {
                loggedInUserId?.let { userId ->
                    ProfileScreen(profileViewModel, userId, onLogout = {
                        authViewModel.logout()
                        navController.navigate("login") {
                            popUpTo(Screen.Profile.route) { inclusive = true }
                        }
                    }, onUpdateImage = onUpdateImage)
                }
            }
            composable(Screen.Routines.route) { MyRoutinesScreen(profileViewModel) }
            composable(Screen.Meals.route) { MyMealPlansScreen(profileViewModel) }
            composable(Screen.Posts.route) { PostScreen() }
        }
    }
}
