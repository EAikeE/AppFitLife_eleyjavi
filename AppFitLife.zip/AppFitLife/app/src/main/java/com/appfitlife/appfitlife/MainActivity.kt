package com.appfitlife.appfitlife
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.appfitlife.appfitlife.ui.theme.AppFitLifeTheme
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.pow
data class RegisteredUser(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var lastName: String,
    var passwordHash: String,
    var gender: String,
    var weight: String,
    var height: String,
    var age: String
)
data class UserProfile(
    var name: String,
    var weight: Float,
    var height: Int,
    var age: Int,
    var imageUri: Uri? = null, // Para la foto de perfil
    val routines: SnapshotStateList<Routine> = mutableStateListOf(),
    val mealPlans: SnapshotStateList<MealPlan> = mutableStateListOf()
)
data class Exercise(val id: Int, val name: String, val description: String)
data class SavedExercise(val exercise: Exercise, var quantity: String = "3 series x 12 reps")
data class Routine(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val exercises: SnapshotStateList<SavedExercise> = mutableStateListOf()
)
val availableExercises = listOf(
    Exercise(1, "Flexiones (Push-ups)", "Trabaja pecho, hombros y tríceps."),
    Exercise(2, "Sentadillas (Squats)", "Fortalece piernas y glúteos."),
    Exercise(3, "Plancha (Plank)", "Fortalece el core y el abdomen."),
    Exercise(4, "Zancadas (Lunges)", "Ideal para piernas y glúteos."),
    Exercise(5, "Remo con mancuerna", "Fortalece la espalda y bíceps.")
)
data class FoodItem(val id: Int, val name: String, val description: String)
data class SavedFood(val food: FoodItem, var detail: String = "100g")
data class MealPlan(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val foods: SnapshotStateList<SavedFood> = mutableStateListOf()
)
val availableFoods = listOf(
    FoodItem(1, "Pechuga de Pollo", "Alta en proteínas."),
    FoodItem(2, "Arroz Integral", "Carbohidrato complejo."),
    FoodItem(3, "Brócoli", "Rico en vitaminas y fibra."),
    FoodItem(4, "Salmón", "Fuente de Omega-3."),
    FoodItem(5, "Avena", "Ideal para el desayuno."),
    FoodItem(6, "Batido de Proteínas", "Recuperación muscular."),
    FoodItem(7, "Frutos Secos", "Grasas saludables y energía.")
)
data class BmiResult(
    val value: Float,
    val category: String,
    val weightGoalMsg: String
)
class AuthViewModel : ViewModel() {
    private val _registeredUsers = mutableStateListOf<RegisteredUser>()
    val registeredUsers: List<RegisteredUser> = _registeredUsers
    private val _loggedInUser = mutableStateOf<RegisteredUser?>(null)
    val loggedInUser: State<RegisteredUser?> = _loggedInUser
    fun register(name: String, lastName: String, password: String, gender: String, weight: String, height: String, age: String): Boolean {
        if (_registeredUsers.any { it.name.equals(name, ignoreCase = true) }) return false
        val newUser = RegisteredUser(
            name = name,
            lastName = lastName,
            passwordHash = password,
            gender = gender,
            weight = weight,
            height = height,
            age = age
        )
        _registeredUsers.add(newUser)
        return true
    }
    fun login(name: String, password: String): Boolean {
        val user = _registeredUsers.find { it.name.equals(name, ignoreCase = true) && it.passwordHash == password }
        return if (user != null) {
            _loggedInUser.value = user
            true
        } else false
    }
    fun logout() {
        _loggedInUser.value = null
    }
}
class ProfileViewModel : ViewModel() {
    private val _userProfile = mutableStateOf(
        UserProfile(name = "Usuario", weight = 70f, height = 175, age = 30)
    )
    val userProfile: State<UserProfile> = _userProfile
    fun initializeUserProfile(user: RegisteredUser) {
        val weight = user.weight.toFloatOrNull() ?: 70f
        val height = user.height.toIntOrNull() ?: 175
        val age = user.age.toIntOrNull() ?: 30
        val bmiResult = calculateBmiAndWeightGoal(weight, height)
        val suggestedRoutines = mutableStateListOf<Routine>()
        val suggestedPlans = mutableStateListOf<MealPlan>()
        when {
            bmiResult.value < 18.5 -> {
                suggestedRoutines.add(createVolumeRoutine())
                suggestedPlans.add(createSurplusPlan())
            }
            bmiResult.value >= 25 -> {
                suggestedRoutines.add(createDefinitionRoutine())
                suggestedPlans.add(createDeficitPlan())
            }
            else -> {
                suggestedRoutines.add(createMaintenanceRoutine())
                suggestedPlans.add(createMaintenancePlan())
            }
        }
        if (age > 40) {
            suggestedRoutines.add(createLowImpactRoutine())
        }
        _userProfile.value = UserProfile(
            name = user.name,
            weight = weight,
            height = height,
            age = age,
            routines = suggestedRoutines,
            mealPlans = suggestedPlans
        )
    }
    private fun createDefinitionRoutine() = Routine(
        name = "Quemar Grasa (Cardio + Fuerza)",
        exercises = mutableStateListOf(
            SavedExercise(availableExercises[1], "4 series x 15 reps"), // Sentadillas
            SavedExercise(availableExercises[0], "4 series x 12 reps"), // Flexiones
            SavedExercise(availableExercises[2], "4 series x 60 seg")    // Plancha
        )
    )
    private fun createVolumeRoutine() = Routine(
        name = "Ganar Volumen Muscular",
        exercises = mutableStateListOf(
            SavedExercise(availableExercises[4], "4 series x 10 reps"), // Remo
            SavedExercise(availableExercises[1], "4 series x 10 reps"), // Sentadillas
            SavedExercise(availableExercises[3], "3 series x 12 reps")  // Zancadas
        )
    )
    private fun createMaintenanceRoutine() = Routine(
        name = "Mantenimiento General",
        exercises = mutableStateListOf(
            SavedExercise(availableExercises.random(), "3 series x 12 reps"),
            SavedExercise(availableExercises.random(), "3 series x 12 reps"),
            SavedExercise(availableExercises.random(), "3 series x 12 reps")
        )
    )
    private fun createLowImpactRoutine() = Routine(
        name = "Rutina de Bajo Impacto (Mayores de 40)",
        exercises = mutableStateListOf(
            SavedExercise(availableExercises[2], "3 series x 45 seg"),
            SavedExercise(availableExercises[4], "3 series x 10 reps por pierna"),
            SavedExercise(Exercise(6, "Elevación de talones", "Fortalece pantorrillas"), "3 series x 20 reps")
        )
    )
    private fun createDeficitPlan() = MealPlan(
        name = "Plan de Definición",
        foods = mutableStateListOf(
            SavedFood(availableFoods[0], "150g a la plancha"),
            SavedFood(availableFoods[2], "200g al vapor"),
            SavedFood(availableFoods[3], "150g al horno")
        )
    )
    private fun createSurplusPlan() = MealPlan(
        name = "Plan para Aumentar Masa",
        foods = mutableStateListOf(
            SavedFood(availableFoods[0], "200g a la plancha"),
            SavedFood(availableFoods[1], "150g cocido"),
            SavedFood(availableFoods[6], "40g como snack")
        )
    )
    private fun createMaintenancePlan() = MealPlan(
        name = "Plan de Mantenimiento",
        foods = mutableStateListOf(
            SavedFood(availableFoods.random(), "1 porción"),
            SavedFood(availableFoods.random(), "1 porción"),
            SavedFood(availableFoods.random(), "1 porción")
        )
    )
    fun updateUserName(newName: String) {
        if (newName.isNotBlank()) _userProfile.value = _userProfile.value.copy(name = newName)
    }
    fun updateUserImage(uri: Uri) {
        _userProfile.value = _userProfile.value.copy(imageUri = uri)
    }
    fun calculateBmiAndWeightGoal(weightKg: Float, heightCm: Int): BmiResult {
        if (heightCm <= 0) return BmiResult(0f, "Altura inválida", "")
        val heightM = heightCm / 100f
        val bmi = weightKg / (heightM * heightM)
        val category = when {
            bmi < 18.5 -> "Bajo peso"
            bmi < 25 -> "Peso saludable"
            bmi < 30 -> "Sobrepeso"
            else -> "Obesidad"
        }
        val lowerHealthyWeight = 18.5f * heightM.pow(2)
        val upperHealthyWeight = 24.9f * heightM.pow(2)
        val weightGoalMsg: String
        when {
            bmi < 18.5 -> {
                val weightToGain = lowerHealthyWeight - weightKg
                weightGoalMsg = "Para un peso saludable, deberías subir %.1f kg.".format(weightToGain)
            }
            bmi >= 25 -> {
                val weightToLose = weightKg - upperHealthyWeight
                weightGoalMsg = "Para un peso saludable, deberías perder %.1f kg.".format(weightToLose)
            }
            else -> {
                weightGoalMsg = "¡Estás en un rango de peso saludable, sigue así!"
            }
        }
        return BmiResult(bmi, category, weightGoalMsg)
    }
    fun createRoutine(name: String) { if (name.isNotBlank()) _userProfile.value.routines.add(Routine(name = name)) }
    fun deleteRoutine(routine: Routine) { _userProfile.value.routines.remove(routine) }
    fun addExerciseToRoutine(routine: Routine, exercise: Exercise) {
        if (routine.exercises.none { it.exercise.id == exercise.id }) {
            routine.exercises.add(SavedExercise(exercise = exercise))
        }
    }
    fun removeExerciseFromRoutine(routine: Routine, savedExercise: SavedExercise) { routine.exercises.remove(savedExercise) }
    fun updateExerciseQuantity(routine: Routine, savedExercise: SavedExercise, newQuantity: String) {
        val index = routine.exercises.indexOf(savedExercise)
        if (index != -1) routine.exercises[index] = savedExercise.copy(quantity = newQuantity)
    }
    fun createMealPlan(name: String) {
        if (name.isNotBlank()) _userProfile.value.mealPlans.add(MealPlan(name = name))
    }
    fun deleteMealPlan(plan: MealPlan) { _userProfile.value.mealPlans.remove(plan) }
    fun addFoodToPlan(plan: MealPlan, food: FoodItem) {
        if (plan.foods.none { it.food.id == food.id }) {
            plan.foods.add(SavedFood(food = food))
        }
    }
    fun removeFoodFromPlan(plan: MealPlan, savedFood: SavedFood) { plan.foods.remove(savedFood) }
    fun updateFoodDetail(plan: MealPlan, savedFood: SavedFood, newDetail: String) {
        val index = plan.foods.indexOf(savedFood)
        if (index != -1) plan.foods[index] = savedFood.copy(detail = newDetail)
    }
}
class MainActivity : ComponentActivity() {
    private val authViewModel: AuthViewModel by viewModels()
    private val profileViewModel: ProfileViewModel by viewModels() // Instancia única
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppFitLifeTheme {
                AppFitLife(authViewModel = authViewModel, profileViewModel = profileViewModel)
            }
        }
    }
}
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun AppFitLife(authViewModel: AuthViewModel, profileViewModel: ProfileViewModel) {
    val loggedInUser by authViewModel.loggedInUser
    val isLoggedIn = loggedInUser != null

    var isLoading by remember { mutableStateOf(false) }

    LaunchedEffect(loggedInUser) {
        if (loggedInUser != null) {
            isLoading = true
            loggedInUser?.let { user ->
                profileViewModel.initializeUserProfile(user)
                isLoading = false
            }
        } else {
            isLoading = false
        }
    }

    val targetState = when {
        !isLoggedIn -> 0
        isLoading -> 1
        else -> 2
    }

    AnimatedContent(
        targetState = targetState,
        transitionSpec = {
            // Animación de 1 segundo para la transición principal
            fadeIn(animationSpec = tween(1000)) with fadeOut(animationSpec = tween(1000))
        },
        label = "app-state-transition"
    ) { state ->
        when (state) {
            0 -> AuthScreen(authViewModel = authViewModel)
            1 -> LoadingScreen()
            2 -> MainAppScreen(profileViewModel = profileViewModel)
        }
    }
}

// 4. Nuevo Composable de la Pantalla de Carga
@Composable
fun LoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(
                modifier = Modifier.size(64.dp),
                strokeWidth = 6.dp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Cargando tu perfil...",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}
data class NavItem(val route: String, val label: String, val icon: ImageVector)
val navItems = listOf(
    NavItem(route = "profile", label = "Perfil", icon = Icons.Default.AccountCircle),
    NavItem(route = "routines", label = "Rutinas", icon = Icons.Default.FitnessCenter),
    NavItem(route = "nutrition", label = "Nutrición", icon = Icons.Default.Restaurant)
)
@OptIn(ExperimentalAnimationApi::class) // <-- 1. AÑADE ESTA ANOTACIÓN
@Composable
fun MainAppScreen(profileViewModel: ProfileViewModel = viewModel()) {
    var currentRoute by remember { mutableStateOf("profile") }
    val userProfile by profileViewModel.userProfile
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                navItems.forEach { item ->
                    NavigationBarItem(
                        icon = { Icon(imageVector = item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        selected = currentRoute == item.route,
                        onClick = { currentRoute = item.route },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier
            .padding(innerPadding)
            .background(Brush.verticalGradient(listOf(Color(0xFFF0F4F8), Color(0xFFE0F2FE))))) {
            AnimatedContent(
                targetState = currentRoute,
                transitionSpec = {
                    // Animación de 500ms para el cambio de pestañas
                    fadeIn(animationSpec = tween(500)) with fadeOut(animationSpec = tween(500))
                },
                label = "screen-transition"
            ) { route ->
                when (route) {
                    "routines" -> RoutinesNavigator(routines = userProfile.routines, profileViewModel = profileViewModel)
                    "nutrition" -> NutritionNavigator(mealPlans = userProfile.mealPlans, profileViewModel = profileViewModel)
                    "profile" -> ProfileScreen(profile = userProfile, viewModel = profileViewModel)
                }
            }
        }
    }
}
@Composable
fun AuthScreen(authViewModel: AuthViewModel) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(navController = navController, viewModel = authViewModel)
        }
        composable("register") {
            RegisterScreen(navController = navController, viewModel = authViewModel)
        }
    }
}
@Composable
fun LoginScreen(navController: NavController, viewModel: AuthViewModel) {
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    LazyColumn(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        item {
            AnimatedVisibility(
                visible = true,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
            ) {
                Text("Iniciar Sesión", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(32.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre de usuario") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(16.dp))
            PasswordTextField(
                value = password,
                onValueChange = { password = it },
                label = "Contraseña",
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(24.dp))
            errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 8.dp))
            }
            Button(
                onClick = {
                    if (viewModel.login(name, password)) {
                        errorMessage = null
                    } else {
                        errorMessage = "Nombre de usuario o contraseña incorrectos."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Entrar")
            }
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { navController.navigate("register") }) {
                Text("¿No tienes cuenta? Regístrate")
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(navController: NavController, viewModel: AuthViewModel) {
    var name by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf<String?>(null) }
    var lastNameError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var genderError by remember { mutableStateOf<String?>(null) }
    var weightError by remember { mutableStateOf<String?>(null) }
    var heightError by remember { mutableStateOf<String?>(null) }
    var ageError by remember { mutableStateOf<String?>(null) }
    var genderMenuExpanded by remember { mutableStateOf(false) }
    val genderOptions = listOf("Masculino", "Femenino", "Otro")
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    fun validateFields(): Boolean {
        nameError = if (name.isBlank()) "El nombre es obligatorio" else null
        lastNameError = if (lastName.isBlank()) "El apellido es obligatorio" else null
        passwordError = if (password.length < 6) "La contraseña debe tener al menos 6 caracteres" else null
        genderError = if (gender.isBlank()) "Debes seleccionar un género" else null
        weightError = if (weight.toFloatOrNull() == null) "El peso debe ser un número" else null
        heightError = if (height.toIntOrNull() == null) "La altura debe ser un número entero" else null
        ageError = if (age.toIntOrNull() == null) "La edad debe ser un número entero" else null
        return nameError == null && lastNameError == null && passwordError == null && genderError == null && weightError == null && heightError == null && ageError == null
    }
    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(it)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                AnimatedVisibility(
                    visible = true,
                    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
                ) {
                    Text("Crear Cuenta", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(24.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre de usuario") }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = nameError != null, supportingText = { nameError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(value = lastName, onValueChange = { lastName = it }, label = { Text("Apellido") }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = lastNameError != null, supportingText = { lastNameError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))
                PasswordTextField(value = password, onValueChange = { password = it }, label = "Contraseña", modifier = Modifier.fillMaxWidth(), isError = passwordError != null, supportingText = { passwordError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))
                ExposedDropdownMenuBox(
                    expanded = genderMenuExpanded,
                    onExpandedChange = { genderMenuExpanded = !genderMenuExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = gender,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Sexo") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = genderMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        isError = genderError != null,
                        supportingText = { genderError?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
                    )
                    ExposedDropdownMenu(
                        expanded = genderMenuExpanded,
                        onDismissRequest = { genderMenuExpanded = false }
                    ) {
                        genderOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    gender = option
                                    genderMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Peso (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = weightError != null, supportingText = { weightError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Altura (cm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = heightError != null, supportingText = { heightError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Edad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = ageError != null, supportingText = { ageError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = {
                        if (validateFields()) {
                            if (viewModel.register(name, lastName, password, gender, weight, height, age)) {
                                navController.navigate("login") {
                                    popUpTo("login") { inclusive = true }
                                }
                            } else {
                                nameError = "El nombre de usuario ya está en uso."
                            }
                        } else {
                            scope.launch {
                                snackbarHostState.showSnackbar("Faltan campos por completar")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Registrarse")
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = { navController.popBackStack() }) {
                    Text("¿Ya tienes cuenta? Inicia sesión")
                }
            }
        }
    }
}
@Composable
fun ProfileScreen(profile: UserProfile, viewModel: ProfileViewModel) {
    var showEditNameDialog by remember { mutableStateOf(false) }
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.updateUserImage(it) }
    }
    if (showEditNameDialog) {
        EditDetailDialog(
            title = "Editar Nombre", label = "Tu nombre", itemName = "", initialValue = profile.name,
            onDismiss = { showEditNameDialog = false },
            onSave = { newName -> viewModel.updateUserName(newName); showEditNameDialog = false }
        )
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            AnimatedVisibility(
                visible = true,
                enter = scaleIn(initialScale = 0.8f) + fadeIn(),
                exit = scaleOut(targetScale = 0.8f) + fadeOut()
            ) {
                Box(contentAlignment = Alignment.BottomEnd) {
                    AsyncImage(
                        model = profile.imageUri,
                        contentDescription = "Foto de perfil",
                        placeholder = painterResource(id = R.drawable.ic_launcher_foreground), // Asegúrate que este drawable exista
                        error = painterResource(id = R.drawable.ic_launcher_foreground),
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    IconButton(
                        onClick = { imagePickerLauncher.launch("image/*") },
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Cambiar foto", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { showEditNameDialog = true }
            ) {
                Text(text = profile.name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(imageVector = Icons.Default.Edit, contentDescription = "Editar nombre", modifier = Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(modifier = Modifier.height(32.dp))
        }
        item {
            val bmiResult = viewModel.calculateBmiAndWeightGoal(profile.weight, profile.height)
            IMCSummaryCard(bmiResult = bmiResult)
            Spacer(modifier = Modifier.height(24.dp))
        }
        item {
            Text("Resumen de Actividad", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(16.dp))
        }
        item {
            SummaryCard(
                icon = Icons.Outlined.FitnessCenter,
                title = "Carpetas de Rutinas",
                count = profile.routines.size,
                label = "rutinas",
                colors = Pair(Color(0xFF6A11CB), Color(0xFF2575FC))
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
        item {
            SummaryCard(
                icon = Icons.Outlined.Restaurant,
                title = "Planes de Nutrición",
                count = profile.mealPlans.size,
                label = "planes",
                colors = Pair(Color(0xFFFC5C7D), Color(0xFF6A82FB))
            )
        }
    }
}
@Composable
fun LoadingDetailScreen(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun RoutinesNavigator(routines: List<Routine>, profileViewModel: ProfileViewModel) {
    var selectedRoutine by remember { mutableStateOf<Routine?>(null) }
    var isLoadingDetail by remember { mutableStateOf(false) }

    val targetRoutine = if (isLoadingDetail) null else selectedRoutine

    AnimatedContent(targetState = targetRoutine, label = "routines-anim") { routine ->
        if (routine == null) {
            if (isLoadingDetail) {
                LoadingDetailScreen(message = "Cargando rutina...")
            } else {
                RoutinesListScreen(
                    routines = routines,
                    onCreateRoutine = { name -> profileViewModel.createRoutine(name) },
                    onRoutineClick = { r ->
                        isLoadingDetail = true
                        selectedRoutine = r
                    },
                    onDeleteRoutine = { r -> profileViewModel.deleteRoutine(r) }
                )
            }
        } else {
            // Aumentado el retraso simulado a 1000ms (1 segundo)
            LaunchedEffect(routine) {
                kotlinx.coroutines.delay(1000L)
                isLoadingDetail = false
            }
            RoutineDetailScreen(
                routine = routine,
                viewModel = profileViewModel,
                onBack = { selectedRoutine = null; isLoadingDetail = false }
            )
        }
    }
}
@Composable
fun RoutinesListScreen(routines: List<Routine>, onCreateRoutine: (String) -> Unit, onRoutineClick: (Routine) -> Unit, onDeleteRoutine: (Routine) -> Unit) {
    var showCreateDialog by remember { mutableStateOf(false) }
    if (showCreateDialog) {
        CreateDialog(title = "Crear Nueva Rutina", label = "Nombre de la rutina", onDismiss = { showCreateDialog = false }, onSave = { name ->
            onCreateRoutine(name)
            showCreateDialog = false
        })
    }
    Scaffold(floatingActionButton = {
        FloatingActionButton(onClick = { showCreateDialog = true }) {
            Icon(Icons.Default.Add, contentDescription = "Crear nueva rutina")
        }
    }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Text("Mis Carpetas de Rutinas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
            }
            if (routines.isEmpty()) {
                item { Text("No tienes rutinas. ¡Crea una con el botón '+'!", modifier = Modifier.padding(16.dp), textAlign = TextAlign.Center) }
            } else {
                items(routines, key = { it.id }) { routine ->
                    FolderCard(name = routine.name, itemCount = routine.exercises.size, itemLabel = "ejercicios", icon = Icons.Default.FitnessCenter, onClick = { onRoutineClick(routine) }, onDelete = { onDeleteRoutine(routine) })
                }
            }
        }
    }
}
@Composable
fun RoutineDetailScreen(routine: Routine, viewModel: ProfileViewModel, onBack: () -> Unit) {
    var exerciseToEdit by remember { mutableStateOf<SavedExercise?>(null) }
    exerciseToEdit?.let { savedExercise ->
        EditDetailDialog(title = "Editar Cantidad", label = "Cantidad (ej: 15 reps)", initialValue = savedExercise.quantity, itemName = savedExercise.exercise.name, onDismiss = { exerciseToEdit = null }, onSave = { updatedQuantity ->
            viewModel.updateExerciseQuantity(routine, savedExercise, updatedQuantity)
            exerciseToEdit = null
        })
    }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item { ScreenHeader(title = routine.name, onBack = onBack) }
        if (routine.exercises.isEmpty()) {
            item { EmptyListMessage("Esta rutina está vacía. ¡Añade ejercicios de la lista de abajo!") }
        } else {
            items(routine.exercises, key = { it.exercise.id }) { savedExercise ->
                SavedItemCard(name = savedExercise.exercise.name, detail = "Cantidad: ${savedExercise.quantity}", onClick = { exerciseToEdit = savedExercise }, onRemove = { viewModel.removeExerciseFromRoutine(routine, savedExercise) })
            }
        }
        item { ListDivider(title = "Ejercicios Disponibles") }
        items(availableExercises) { exercise ->
            AvailableItemCard(name = exercise.name, description = exercise.description, onAdd = { viewModel.addExerciseToRoutine(routine, exercise) })
        }
    }
}
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NutritionNavigator(mealPlans: List<MealPlan>, profileViewModel: ProfileViewModel) {
    var selectedPlan by remember { mutableStateOf<MealPlan?>(null) }
    var isLoadingDetail by remember { mutableStateOf(false) }
    val targetPlan = if (isLoadingDetail) null else selectedPlan
    AnimatedContent(targetState = targetPlan, label = "nutrition-anim") { plan ->
        if (plan == null) {
            if (isLoadingDetail) {
                LoadingDetailScreen(message = "Cargando plan de comidas...")
            } else {
                MealPlanListScreen(
                    mealPlans = mealPlans,
                    onCreatePlan = { name -> profileViewModel.createMealPlan(name) },
                    onPlanClick = { p ->
                        isLoadingDetail = true
                        selectedPlan = p
                    },
                    onDeletePlan = { p -> profileViewModel.deleteMealPlan(p) }
                )
            }
        } else {
            LaunchedEffect(plan) {
                kotlinx.coroutines.delay(1000L)
                isLoadingDetail = false
            }
            MealPlanDetailScreen(plan = plan, viewModel = profileViewModel, onBack = { selectedPlan = null; isLoadingDetail = false })
        }
    }
}
@Composable
fun MealPlanListScreen(mealPlans: List<MealPlan>, onCreatePlan: (String) -> Unit, onPlanClick: (MealPlan) -> Unit, onDeletePlan: (MealPlan) -> Unit) {
    var showCreateDialog by remember { mutableStateOf(false) }
    if (showCreateDialog) {
        CreateDialog(title = "Crear Nuevo Plan de Comida", label = "Nombre del plan", onDismiss = { showCreateDialog = false }, onSave = { name ->
            onCreatePlan(name)
            showCreateDialog = false
        })
    }
    Scaffold(floatingActionButton = {
        FloatingActionButton(onClick = { showCreateDialog = true }) {
            Icon(Icons.Default.Add, contentDescription = "Crear nuevo plan de comida")
        }
    }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Text("Mis Planes de Comida", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
            }
            if (mealPlans.isEmpty()) {
                item { Text("No tienes planes de comida. ¡Crea uno con el botón '+'!", modifier = Modifier.padding(16.dp), textAlign = TextAlign.Center) }
            } else {
                items(mealPlans, key = { it.id }) { plan ->
                    FolderCard(name = plan.name, itemCount = plan.foods.size, itemLabel = "alimentos", icon = Icons.Default.Restaurant, onClick = { onPlanClick(plan) }, onDelete = { onDeletePlan(plan) })
                }
            }
        }
    }
}
@Composable
fun MealPlanDetailScreen(plan: MealPlan, viewModel: ProfileViewModel, onBack: () -> Unit) {
    var foodToEdit by remember { mutableStateOf<SavedFood?>(null) }
    foodToEdit?.let { savedFood ->
        EditDetailDialog(title = "Editar Detalle", label = "Cantidad (ej: 150g)", initialValue = savedFood.detail, itemName = savedFood.food.name, onDismiss = { foodToEdit = null }, onSave = { updatedDetail ->
            viewModel.updateFoodDetail(plan, savedFood, updatedDetail)
            foodToEdit = null
        })
    }
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item { ScreenHeader(title = plan.name, onBack = onBack) }
        if (plan.foods.isEmpty()) {
            item { EmptyListMessage("Este plan está vacío. ¡Añade alimentos de la lista de abajo!") }
        } else {
            items(plan.foods, key = { it.food.id }) { savedFood ->
                SavedItemCard(name = savedFood.food.name, detail = "Cantidad: ${savedFood.detail}", onClick = { foodToEdit = savedFood }, onRemove = { viewModel.removeFoodFromPlan(plan, savedFood) })
            }
        }
        item { ListDivider(title = "Alimentos Disponibles") }
        items(availableFoods) { food ->
            AvailableItemCard(name = food.name, description = food.description, onAdd = { viewModel.addFoodToPlan(plan, food) })
        }
    }
}
@Composable
fun PasswordTextField(value: String, onValueChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, isError: Boolean = false, supportingText: @Composable (() -> Unit)? = null) {
    var passwordVisibility by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        visualTransformation = if (passwordVisibility) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        trailingIcon = {
            val image = if (passwordVisibility) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
            IconButton(onClick = { passwordVisibility = !passwordVisibility }) {
                Icon(imageVector = image, contentDescription = "Toggle password visibility")
            }
        },
        isError = isError,
        supportingText = supportingText
    )
}
@Composable
fun EditDetailDialog(title: String, label: String, itemName: String, initialValue: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var detail by remember { mutableStateOf(initialValue) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                if (itemName.isNotBlank()) {
                    Text("Define el detalle para $itemName:")
                    Spacer(modifier = Modifier.height(16.dp))
                }
                OutlinedTextField(value = detail, onValueChange = { detail = it }, label = { Text(label) }, singleLine = true)
            }
        },
        confirmButton = { Button(onClick = { onSave(detail) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
@Composable
fun IMCSummaryCard(bmiResult: BmiResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Tu Índice de Masa Corporal (IMC)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = String.format("%.1f", bmiResult.value),
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = bmiResult.category,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = bmiResult.weightGoalMsg,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                fontWeight = FontWeight.Medium
            )
        }
    }
}
@Composable
fun SummaryCard(icon: ImageVector, title: String, count: Int, label: String, colors: Pair<Color, Color>) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Row(
            modifier = Modifier
                .background(Brush.horizontalGradient(listOf(colors.first, colors.second)))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(40.dp), tint = Color.White)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Tienes $count $label", style = MaterialTheme.typography.bodyLarge, color = Color.White.copy(alpha = 0.8f))
            }
        }
    }
}
@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver") }
        Spacer(modifier = Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    }
    Spacer(modifier = Modifier.height(16.dp))
}
@Composable
fun EmptyListMessage(message: String) {
    Text(text = message, modifier = Modifier.padding(16.dp), textAlign = TextAlign.Center)
}
@Composable
fun ListDivider(title: String) {
    HorizontalDivider(modifier = Modifier.padding(vertical = 24.dp))
    Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Spacer(modifier = Modifier.height(16.dp))
}
@Composable
fun CreateDialog(title: String, label: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { Button(onClick = { onSave(name) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
@Composable
fun FolderCard(name: String, itemCount: Int, itemLabel: String, icon: ImageVector, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(onClick = onClick), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(40.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("$itemCount $itemLabel", style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Borrar") }
        }
    }
}
@Composable
fun AvailableItemCard(name: String, description: String, onAdd: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = name, fontWeight = FontWeight.Bold)
                Text(text = description, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onAdd) { Icon(Icons.Default.AddCircle, contentDescription = "Añadir") }
        }
    }
}
@Composable
fun SavedItemCard(name: String, detail: String, onClick: () -> Unit, onRemove: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Edit, contentDescription = "Editar", tint = MaterialTheme.colorScheme.secondary)
            Column(modifier = Modifier.padding(horizontal = 16.dp).weight(1f)) {
                Text(text = name, fontWeight = FontWeight.Bold)
                Text(text = detail, style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, contentDescription = "Quitar") }
        }
    }
}
@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    AppFitLifeTheme {
        AppFitLife(authViewModel = viewModel(), profileViewModel = viewModel())
    }
}