package com.appfitlife.appfitlife.viewmodel

import android.app.Application
import com.appfitlife.appfitlife.data.MealPlanDao
import com.appfitlife.appfitlife.data.RoutineDao
import com.appfitlife.appfitlife.data.UserRepository
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.mockk.mockk

class ProfileViewModelTest : StringSpec({

    lateinit var viewModel: ProfileViewModel

    beforeTest {
        // Mock de todas las dependencias necesarias para el ViewModel
        val application: Application = mockk(relaxed = true)
        val userRepository: UserRepository = mockk(relaxed = true)
        val routineDao: RoutineDao = mockk(relaxed = true)
        val mealPlanDao: MealPlanDao = mockk(relaxed = true)

        // Instanciamos el ViewModel con los mocks
        viewModel = ProfileViewModel(userRepository, routineDao, mealPlanDao, application)
    }

    "BMI calculation for 50kg and 180cm should be underweight" {
        val result = viewModel.calculateBmiAndWeightGoal(weightKg = 50f, heightCm = 180f)
        result.category shouldBe "Bajo peso"
    }

    "BMI calculation for 70kg and 175cm should be healthy weight" {
        val result = viewModel.calculateBmiAndWeightGoal(weightKg = 70f, heightCm = 175f)
        result.category shouldBe "Peso saludable"
    }

    "BMI calculation for 85kg and 175cm should be overweight" {
        val result = viewModel.calculateBmiAndWeightGoal(weightKg = 85f, heightCm = 175f)
        result.category shouldBe "Sobrepeso"
    }

    "BMI calculation for 100kg and 175cm should be obese" {
        val result = viewModel.calculateBmiAndWeightGoal(weightKg = 100f, heightCm = 175f)
        result.category shouldBe "Obesidad"
    }

    "BMI calculation should return invalid data for 0 height" {
        val result = viewModel.calculateBmiAndWeightGoal(weightKg = 70f, heightCm = 0f)
        result.category shouldBe "Datos inválidos"
    }
})