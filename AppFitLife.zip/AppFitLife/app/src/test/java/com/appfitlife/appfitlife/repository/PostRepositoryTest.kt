package com.appfitlife.appfitlife.repository

import com.appfitlife.appfitlife.data.model.Post
import com.appfitlife.appfitlife.data.remote.ApiService
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import java.io.IOException

class PostRepositoryTest : StringSpec({

    lateinit var apiService: ApiService
    lateinit var repository: PostRepository

    beforeTest {
        apiService = mockk()
        repository = PostRepository()
        val field = repository.javaClass.getDeclaredField("apiService")
        field.isAccessible = true
        field.set(repository, apiService)
    }

    "getPosts should return a list of posts on successful fetch" { 
        runTest {
            // Given
            val expectedPosts = listOf(Post(1, 1, "title", "body"))
            coEvery { apiService.getPosts() } returns expectedPosts

            // When
            val result = repository.getPosts()

            // Then
            result shouldBe expectedPosts
        }
    }

    "getPosts should return an empty list when api returns empty" {
        runTest {
            // Given
            coEvery { apiService.getPosts() } returns emptyList()

            // When
            val result = repository.getPosts()

            // Then
            result shouldBe emptyList()
        }
    }

    "getPosts should rethrow exceptions from api" {
        runTest {
            // Given
            val exception = IOException("Network error")
            coEvery { apiService.getPosts() } throws exception

            // When
            val thrownException = try {
                repository.getPosts()
                null
            } catch (e: IOException) {
                e
            }

            // Then
            thrownException shouldBe exception
        }
    }
})