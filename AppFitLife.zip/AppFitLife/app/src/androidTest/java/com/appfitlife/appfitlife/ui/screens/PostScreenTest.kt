package com.appfitlife.appfitlife.ui.screens

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.appfitlife.appfitlife.data.model.Post
import com.appfitlife.appfitlife.repository.FakePostRepository
import com.appfitlife.appfitlife.viewmodel.PostViewModel
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PostScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun postScreen_displaysPosts_whenLoaded() {
        // Given
        val repository = FakePostRepository()
        val posts = listOf(
            Post(1, 1, "Title 1", "Body 1"),
            Post(2, 2, "Title 2", "Body 2")
        )
        repository.setPosts(posts)
        val viewModel = PostViewModel(repository)

        // When
        composeTestRule.setContent {
            PostScreen(postViewModel = viewModel)
        }

        // Then
        composeTestRule.onNodeWithText("Title 1").assertIsDisplayed()
        composeTestRule.onNodeWithText("Body 1").assertIsDisplayed()
        composeTestRule.onNodeWithText("Title 2").assertIsDisplayed()
        composeTestRule.onNodeWithText("Body 2").assertIsDisplayed()
    }

    @Test
    fun postScreen_showsEmptyMessage_whenNoPosts() {
        // Given
        val repository = FakePostRepository()
        repository.setPosts(emptyList())
        val viewModel = PostViewModel(repository)

        // When
        composeTestRule.setContent {
            PostScreen(postViewModel = viewModel)
        }

        // Then
        composeTestRule.onNodeWithText("No posts found").assertIsDisplayed()
    }

    @Test
    fun postScreen_showsErrorMessage_whenError() {
        // Given
        val repository = FakePostRepository()
        repository.setShouldThrowError(true)
        val viewModel = PostViewModel(repository)

        // When
        composeTestRule.setContent {
            PostScreen(postViewModel = viewModel)
        }

        // Then
        composeTestRule.onNodeWithText("Error fetching posts").assertIsDisplayed()
    }
}