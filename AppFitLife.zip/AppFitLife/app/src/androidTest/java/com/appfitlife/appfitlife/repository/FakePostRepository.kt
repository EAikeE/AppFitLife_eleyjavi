package com.appfitlife.appfitlife.repository

import com.appfitlife.appfitlife.data.model.Post

class FakePostRepository : PostRepository() {

    private var posts: List<Post>? = null
    private var shouldThrowError = false

    fun setPosts(posts: List<Post>) {
        this.posts = posts
        this.shouldThrowError = false
    }

    fun setShouldThrowError(shouldThrow: Boolean) {
        this.shouldThrowError = shouldThrow
    }

    override suspend fun getPosts(): List<Post> {
        if (shouldThrowError) {
            throw Exception("Network Error")
        }
        return posts ?: emptyList()
    }
}
