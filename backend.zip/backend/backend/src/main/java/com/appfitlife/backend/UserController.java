package com.appfitlife.backend;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@RestController
@RequestMapping("/api")
public class UserController {

    @GetMapping("/users")
    public List<User> getAllUsers() {
        System.out.println("-> Devolviendo todos los usuarios de la base de datos simulada.");
        return userDatabase;
    }

    private final List<User> userDatabase = new CopyOnWriteArrayList<>();
    private long userIdCounter = 1;

    public UserController() {
        // Precargamos un usuario de ejemplo con todos los campos
        userDatabase.add(new User("0", "Elena Ejemplo", "elena@example.com", "password123", 30, 65.5, 1.70));
    }

    // CREATE: POST /api/users
    @PostMapping("/users")
    @ResponseStatus(HttpStatus.CREATED)
    public User createUser(@RequestBody User user) {
        user.setId(String.valueOf(userIdCounter++));
        userDatabase.add(user);
        System.out.println("-> Usuario CREADO: " + user);
        return user;
    }

    // READ: GET /api/users/{id}
    @GetMapping("/users/{id}")
    public ResponseEntity<User> getUserById(@PathVariable String id) {
        System.out.println("-> Buscando usuario con ID: " + id);
        return userDatabase.stream()
                .filter(u -> u.getId().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // UPDATE: PUT /api/users/{id}
    @PutMapping("/users/{id}")
    public ResponseEntity<User> updateUser(@PathVariable String id, @RequestBody User updatedUser) {
        for (int i = 0; i < userDatabase.size(); i++) {
            if (userDatabase.get(i).getId().equals(id)) {
                updatedUser.setId(id);
                userDatabase.set(i, updatedUser);
                System.out.println("-> Usuario ACTUALIZADO: " + updatedUser);
                return ResponseEntity.ok(updatedUser);
            }
        }
        return ResponseEntity.notFound().build();
    }
}
