package com.appfitlife.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
        System.out.println("\n*** SERVIDOR DE SPRING BOOT INICIADO ***");
        System.out.println("*** Escuchando en http://10.0.2.2:8080/api/ ***");
        System.out.println("****************************************\n");
    }

}
