// build.gradle.kts (a nivel de proyecto raíz) (CORRECTO)
plugins {
    // Usamos los alias definidos en el archivo libs.versions.toml
    alias(libs.plugins.androidApplication) apply false
    alias(libs.plugins.kotlinAndroid) apply false
    // Corregimos el alias para apuntar al nuevo plugin del compilador de Compose
    alias(libs.plugins.kotlinComposeCompiler) apply false
    alias(libs.plugins.ksp) apply false
}