package com.appfitlife.appfitlife

import android.app.Application
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.appfitlife.appfitlife.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID
import kotlin.math.pow

class AuthViewModel(private val userRepository: UserRepository) : ViewModel() {
    private val _authResult = MutableStateFlow<AuthResult?>(null)
    val authResult: StateFlow<AuthResult?> = _authResult.asStateFlow()

    private val _loggedInUserId = MutableStateFlow<String?>(null)
    val loggedInUserId: StateFlow<String?> = _loggedInUserId.asStateFlow()

    fun login(name: String, password: String) {
        viewModelScope.launch {
            val user = userRepository.getUserByName(name)
            if (user != null && user.password == password) {
                _loggedInUserId.value = user.id
                _authResult.value = AuthResult.Success(user)
            } else {
                _authResult.value = AuthResult.Failure("Usuario no encontrado o contraseña incorrecta.")
            }
        }
    }

    fun register(name: String, email: String, password: String, ageStr: String, weightStr: String, heightStr: String, gender: String) {
        viewModelScope.launch {
            if (userRepository.getUserByName(name) != null) {
                _authResult.value = AuthResult.Failure("El nombre de usuario ya existe.")
                return@launch
            }
            val newUser = User(
                id = UUID.randomUUID().toString(), 
                name = name, 
                email = email,
                password = password,
                age = ageStr.toIntOrNull(), 
                weight = weightStr.toDoubleOrNull(), 
                height = heightStr.toDoubleOrNull(),
                imageUri = null, 
                gender = gender,
                excludedFoods = emptyList(),
                targetWeight = null
            )
            userRepository.insertUser(newUser)
            _loggedInUserId.value = newUser.id
            _authResult.value = AuthResult.Success(newUser)
        }
    }

    fun logout() {
        _loggedInUserId.value = null
        _authResult.value = AuthResult.LoggedOut
    }

    fun clearAuthResult() {
        _authResult.value = null
    }
}

data class UserProfileState(
    val user: User? = null,
    val routines: List<RoutineWithExercises> = emptyList(),
    val mealPlans: List<MealPlanWithFoods> = emptyList(),
    val initialSetupDone: Boolean = false
)

class ProfileViewModel(
    private val userRepository: UserRepository,
    private val routineDao: RoutineDao,
    private val mealPlanDao: MealPlanDao
) : ViewModel() {

    private val _userProfile = MutableStateFlow(UserProfileState())
    val userProfile: StateFlow<UserProfileState> = _userProfile.asStateFlow()

    fun initializeUserProfile(userId: String) {
        viewModelScope.launch {
            userRepository.getUserById(userId)?.let { user ->
                _userProfile.update { it.copy(user = user) }
                combine(
                    routineDao.getRoutinesForUser(user.id),
                    mealPlanDao.getMealPlansForUser(user.id)
                ) { routines, mealPlans ->
                    _userProfile.value.copy(
                        routines = routines,
                        mealPlans = mealPlans,
                        initialSetupDone = true
                    )
                }.onEach { state ->
                    _userProfile.value = state
                }.launchIn(viewModelScope)
            }
        }
    }

    fun calculateWeightGoalDate(currentWeight: Float, targetWeight: Float): String {
        if (currentWeight <= 0 || targetWeight <= 0) return ""
        val diff = kotlin.math.abs(currentWeight - targetWeight)
        if (diff < 0.5) return "Ya estás en tu peso objetivo."
        val weeks = kotlin.math.ceil(diff / 0.5).toInt()
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.WEEK_OF_YEAR, weeks)
        val date = calendar.time
        val formattedDate = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(date)
        
        val months = weeks / 4
        val remainingWeeks = weeks % 4
        val timeString = when {
            months > 0 && remainingWeeks > 0 -> "$months meses y $remainingWeeks semanas"
            months > 0 -> "$months meses"
            else -> "$weeks semanas"
        }
        
        return "Fecha estimada: $formattedDate (aprox. $timeString)."
    }

    fun setWeightGoalAndGeneratePlan(user: User, targetWeightKg: Float): String {
        val currentWeight = user.weight?.toFloat() ?: 0f
        if (currentWeight <= 0 || targetWeightKg <= 0) return "Por favor, introduce un peso válido."

        val goal = if (targetWeightKg < currentWeight) "loss" else "gain"

        viewModelScope.launch {
            val updatedUser = user.copy(targetWeight = targetWeightKg.toDouble())
            userRepository.updateUser(updatedUser)
            _userProfile.update { it.copy(user = updatedUser) }

            routineDao.deleteRoutinesForUser(user.id)
            mealPlanDao.deleteMealPlansForUser(user.id)
            generateWeeklyPlan(goal, user.id, updatedUser.excludedFoods ?: emptyList())
        }

        return ("¡Plan semanal generado para alcanzar %.1f kg!").format(targetWeightKg)
    }

    private suspend fun generateWeeklyPlan(goal: String, userId: String, excludedFoods: List<String>) {
        val days = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
        val routineMap = if (goal == "loss") getWeightLossRoutineMap() else getWeightGainRoutineMap()
        val allMealOptions = if (goal == "loss") getWeightLossMealMap() else getWeightGainMealMap()

        val filteredMealOptions = allMealOptions.mapValues { (_, dayMeals) ->
            dayMeals.mapValues { (_, mealFoods) ->
                mealFoods.filter { (foodName, _) ->
                    // Esta línea ya hace el trabajo de filtrado por alergia
                    excludedFoods.none { excluded -> foodName.contains(excluded.trim(), ignoreCase = true) }
                }
            }.filter { (_, foods) -> foods.isNotEmpty() }
        }

        days.forEach { day ->
            routineMap[day]?.let { (routineName, exercises) ->
                val routineId = routineDao.insertRoutine(RoutineEntity(name = "$day - $routineName", userId = userId))
                exercises.forEach { (exerciseName, details) ->
                    routineDao.getAllExercises().first().find { it.name.equals(exerciseName, ignoreCase = true) }?.let { exercise ->
                        routineDao.insertRoutineExerciseCrossRef(RoutineExerciseCrossRef(routineId, exercise.exerciseId, details))
                    }
                }
            }

            filteredMealOptions[day]?.forEach { (mealType, foods) ->
                if (foods.isNotEmpty()) {
                    val planId = mealPlanDao.insertMealPlan(MealPlanEntity(name = "$day - $mealType", userId = userId))
                    foods.forEach { (foodName, details) ->
                        mealPlanDao.getAllFoodItems().first().find { it.name.equals(foodName, ignoreCase = true) }?.let { food ->
                            mealPlanDao.insertMealPlanFoodCrossRef(MealPlanFoodCrossRef(planId, food.foodItemId, details))
                        }
                    }
                }
            }
        }
    }

    fun updateUserName(newName: String) {
        _userProfile.value.user?.let {
            val updatedUser = it.copy(name = newName)
            viewModelScope.launch { userRepository.updateUser(updatedUser); _userProfile.update { it.copy(user = updatedUser) } }
        }
    }

    fun updateUserImage(imageUri: Uri) {
        _userProfile.value.user?.let {
            val updatedUser = it.copy(imageUri = imageUri.toString())
            viewModelScope.launch {
                userRepository.updateUser(updatedUser)
                _userProfile.update { it.copy(user = updatedUser) }
            }
        }
    }

    fun updateUserExcludedFoods(excludedFoods: List<String>) {
        // Obtenemos el usuario y los planes de comida actuales del estado.
        val currentUser = _userProfile.value.user ?: return

        // Creamos una copia del usuario con la nueva lista de alimentos excluidos.
        val updatedUser = currentUser.copy(excludedFoods = excludedFoods)

        viewModelScope.launch {
            // 1. Guardamos el usuario actualizado en la base de datos.
            userRepository.updateUser(updatedUser)

            // Ya que el plan se regenera basado en la meta, la forma más simple y consistente
            // con tu lógica actual es llamar a la función que ya tienes, pero
            // asegurándote de que use el usuario actualizado.
            // Si el usuario tiene una meta de peso, regeneramos el plan con las nuevas alergias.
            updatedUser.targetWeight?.let { weight ->
                // Borramos los planes viejos
                routineDao.deleteRoutinesForUser(updatedUser.id)
                mealPlanDao.deleteMealPlansForUser(updatedUser.id)

                // Generamos el plan nuevo. Tu función `generateWeeklyPlan` ya sabe cómo filtrar alergias.
                val goal = if (weight.toFloat() < (updatedUser.weight ?: 0.0)) "loss" else "gain"
                generateWeeklyPlan(goal, updatedUser.id, updatedUser.excludedFoods ?: emptyList())
            }

            // 4. Actualizamos el estado de la UI para que el usuario vea los cambios inmediatamente.
            // Esto es importante para que el perfil refleje la nueva lista de alergias.
            // El plan de comidas se actualizará automáticamente porque initializeUserProfile está observando los cambios.
            _userProfile.update {
                it.copy(user = updatedUser)
            }
        }
    }
    fun calculateBmiAndWeightGoal(weightKg: Float, heightCm: Float): BmiResult {
        if (heightCm <= 0 || weightKg <= 0) return BmiResult(0f, "Datos inválidos", "Por favor, asegúrate de que tu peso y altura sean correctos en tu perfil.")
        val heightM = heightCm / 100f
        val bmi = weightKg / (heightM * heightM)
        val category = when {
            bmi < 18.5 -> "Bajo peso"
            bmi < 25 -> "Peso saludable"
            bmi < 30 -> "Sobrepeso"
            else -> "Obesidad"
        }
        val idealMin = 18.5f * heightM.pow(2)
        val idealMax = 24.9f * heightM.pow(2)
        val goalMsg = when (category) {
            "Peso saludable" -> "¡Felicidades! Estás en tu peso ideal (entre %.1f kg y %.1f kg). Puedes enfocarte en mantener tu estilo de vida o tonificar.".format(idealMin, idealMax)
            "Bajo peso" -> "Tu IMC indica bajo peso. Tu rango de peso ideal está entre %.1f kg y %.1f kg. ¡Un plan de superávit calórico y fuerza te ayudará a ganar peso de forma saludable!".format(idealMin, idealMax)
            else -> "Tu IMC indica sobrepeso. Tu rango de peso ideal está entre %.1f kg y %.1f kg. Un buen primer objetivo sería llegar a %.1f kg.".format(idealMin, idealMax, idealMax)
        }
        return BmiResult(bmi, category, goalMsg)
    }
}

class ViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val db = AppDatabase.getDatabase(application)
        val userRepository = UserRepository(db.userDao())

        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(userRepository) as T
        }
        if (modelClass.isAssignableFrom(ProfileViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProfileViewModel(userRepository, db.routineDao(), db.mealPlanDao()) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

fun getWeightLossRoutineMap(): Map<String, Pair<String, Map<String, String>>> = mapOf(
    "Lunes" to ("Cardio y Core" to mapOf("Correr en cinta" to "30 min a 6-7 km/h", "Plancha" to "4 series de 45s", "Burpees" to "3 series de 12 reps")),
    "Martes" to ("Fuerza - Tren Superior" to mapOf("Flexiones" to "4 series al fallo", "Remo con mancuerna" to "4 series de 12 reps por brazo", "Press de hombros" to "3 series de 15 reps")),
    "Miércoles" to ("Descanso Activo" to mapOf("Caminata ligera" to "45 minutos", "Estiramientos" to "15 minutos")),
    "Jueves" to ("Fuerza - Tren Inferior" to mapOf("Sentadillas" to "4 series de 15 reps", "Zancadas" to "3 series de 12 reps por pierna", "Elevación de cadera" to "4x20 reps")),
    "Viernes" to ("HIIT" to mapOf("Saltar la cuerda" to "20 min (1 min on / 30s off)", "Mountain Climbers" to "4 series de 30s", "Jumping Jacks" to "4 series de 45s")),
    "Sábado" to ("Full Body" to mapOf("Peso muerto" to "3x10 reps", "Flexiones" to "3x max reps", "Sentadillas" to "3x15 reps")),
    "Domingo" to ("Descanso" to emptyMap())
)

fun getWeightLossMealMap(): Map<String, Map<String, List<Pair<String, String>>>> = mapOf(
    "Lunes" to mapOf(
        "Desayuno" to listOf("Avena con frutas" to "1 taza", "Té verde" to "1 taza"),
        "Almuerzo" to listOf("Pechuga de Pollo a la plancha" to "150g", "Ensalada de hojas verdes" to "2 tazas", "Quinoa" to "1/2 taza"),
        "Cena" to listOf("Sopa de verduras" to "1 plato hondo", "Yogur Griego" to "1 taza")
    ),
    "Martes" to mapOf(
        "Desayuno" to listOf("Revoltillo de claras" to "3 claras", "Pan integral" to "1 rebanada"),
        "Almuerzo" to listOf("Salmón al horno" to "180g", "Brócoli al vapor" to "1.5 tazas"),
        "Cena" to listOf("Ensalada de atún" to "1 lata en agua", "Galletas integrales" to "4 unidades")
    ),
    "Miércoles" to mapOf(
        "Desayuno" to listOf("Yogur natural con frutos secos" to "1 taza, 30g frutos secos"),
        "Almuerzo" to listOf("Lentejas guisadas" to "1.5 tazas", "Arroz integral" to "1/4 taza"),
        "Cena" to listOf("Pavo a la plancha" to "150g", "Ensalada de pepino y tomate" to "1 taza")
    ),
    "Jueves" to mapOf(
        "Desayuno" to listOf("Batido de proteínas" to "1 scoop", "Plátano" to "1 unidad"),
        "Almuerzo" to listOf("Garbanzos con espinacas" to "1.5 tazas", "Huevo duro" to "1 unidad"),
        "Cena" to listOf("Merluza a la plancha" to "200g", "Puré de calabaza" to "1 taza")
    ),
    "Viernes" to mapOf(
        "Desayuno" to listOf("Tostadas integrales con aguacate" to "2 rebanadas, 1/2 aguacate"),
        "Almuerzo" to listOf("Filete de ternera magra" to "150g", "Pimientos asados" to "1 taza"),
        "Cena" to listOf("Crema de zanahoria" to "1 plato", "Queso fresco" to "100g")
    ),
    "Sábado" to mapOf(
        "Desayuno" to listOf("Avena con frutas" to "1 taza", "Té verde" to "1 taza"),
        "Almuerzo" to listOf("Pollo al horno con hierbas" to "180g", "Ensalada mixta" to "2 tazas"),
        "Cena" to listOf("Ensalada César (versión ligera)" to "1 plato")
    ),
    "Domingo" to mapOf(
        "Desayuno" to listOf("Revoltillo de claras" to "3 claras", "Pan integral" to "1 rebanada"),
        "Almuerzo" to listOf("Comida libre moderada" to "1 porción"),
        "Cena" to listOf("Sopa de verduras" to "1 plato hondo")
    )
)

fun getWeightGainRoutineMap(): Map<String, Pair<String, Map<String, String>>> = mapOf(
    "Lunes" to ("Fuerza - Pecho y Tríceps" to mapOf("Press de banca" to "4 series de 8-10 reps", "Fondos en paralelas" to "4 series de 10 reps", "Press francés" to "3x12 reps")),
    "Martes" to ("Fuerza - Espalda y Bíceps" to mapOf("Dominadas" to "4 series al fallo", "Remo con barra" to "4 series de 8 reps", "Curl de bíceps con barra" to "4x10 reps")),
    "Miércoles" to ("Descanso" to emptyMap()),
    "Jueves" to ("Fuerza - Piernas" to mapOf("Sentadillas" to "5 series de 5 reps", "Peso muerto" to "3 series de 5 reps", "Prensa" to "4x10 reps")),
    "Viernes" to ("Fuerza - Hombros y Core" to mapOf("Press militar" to "4 series de 10 reps", "Elevaciones laterales" to "4x12 reps", "Plancha con peso" to "4 series de 60s")),
    "Sábado" to ("Full Body Hypertrophy" to mapOf("Sentadillas" to "3x12 reps", "Press de banca" to "3x12 reps", "Remo con barra" to "3x12 reps")),
    "Domingo" to ("Descanso" to emptyMap())
)

fun getWeightGainMealMap(): Map<String, Map<String, List<Pair<String, String>>>> = mapOf(
    "Lunes" to mapOf(
        "Desayuno" to listOf("Avena con leche entera y plátano" to "1.5 tazas", "Nueces" to "40g"),
        "Almuerzo" to listOf("Pasta con carne molida" to "2 tazas", "Queso parmesano" to "3 cucharadas"),
        "Cena" to listOf("Pechuga de Pollo" to "200g", "Arroz blanco" to "1.5 tazas", "Aguacate" to "1/2 pieza")
    ),
    "Martes" to mapOf(
        "Desayuno" to listOf("Huevos enteros revueltos" to "4 unidades", "Tostadas con mantequilla" to "2 rebanadas"),
        "Almuerzo" to listOf("Salmón a la plancha" to "200g", "Batata asada" to "2 piezas medianas"),
        "Cena" to listOf("Filete de ternera" to "200g", "Puré de patatas" to "1.5 tazas")
    ),
    "Miércoles" to mapOf(
        "Desayuno" to listOf("Yogur griego con miel y granola" to "1.5 tazas", "Frutos secos" to "50g"),
        "Almuerzo" to listOf("Lentejas con chorizo" to "2 tazas", "Pan" to "2 rebanadas"),
        "Cena" to listOf("Pavo guisado" to "200g", "Arroz con vegetales" to "1.5 tazas")
    ),
    "Jueves" to mapOf(
        "Desayuno" to listOf("Batido hipercalórico" to "Leche, plátano, avena, proteína", "Tostada con crema de cacahuete" to "2 rebanadas"),
        "Almuerzo" to listOf("Hamburguesa casera con queso" to "1 unidad", "Patatas al horno" to "1.5 tazas"),
        "Cena" to listOf("Pescado azul al horno" to "200g", "Quinoa" to "1.5 tazas")
    ),
    "Viernes" to mapOf(
        "Desayuno" to listOf("Huevos enteros revueltos" to "4 unidades", "Tostadas con mantequilla" to "2 rebanadas"),
        "Almuerzo" to listOf("Pasta carbonara" to "2 tazas", "Bacon" to "50g"),
        "Cena" to listOf("Pollo asado" to "1/4 de pollo", "Ensalada de patata" to "1.5 tazas")
    ),
    "Sábado" to mapOf(
        "Desayuno" to listOf("Yogur griego con miel y granola" to "1.5 tazas", "Frutos secos" to "50g"),
        "Almuerzo" to listOf("Comida libre alta en calorías" to "1 porción generosa"),
        "Cena" to listOf("Pizza casera" to "2-3 porciones")
    ),
    "Domingo" to mapOf(
        "Desayuno" to listOf("Batido hipercalórico" to "Leche, plátano, avena, proteína", "Tostada con crema de cacahuete" to "2 rebanadas"),
        "Almuerzo" to listOf("Lasagna de carne" to "1 porción grande"),
        "Cena" to listOf("Restos del almuerzo o cena ligera" to "A gusto")
    )
)
