package com.appfitlife.appfitlife.data

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

data class RoutineWithExercises(
    @Embedded val routine: RoutineEntity,
    @Relation(
        parentColumn = "routineId",
        entityColumn = "exerciseId",
        associateBy = Junction(RoutineExerciseCrossRef::class)
    )
    val exercises: List<Exercise>
)

data class MealPlanWithFoods(
    @Embedded val mealPlan: MealPlanEntity,
    @Relation(
        parentColumn = "mealPlanId",
        entityColumn = "foodItemId",
        associateBy = Junction(MealPlanFoodCrossRef::class)
    )
    val foods: List<FoodItem>
)
