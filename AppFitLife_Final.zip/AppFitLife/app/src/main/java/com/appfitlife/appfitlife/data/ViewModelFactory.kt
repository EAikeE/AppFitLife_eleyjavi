package com.appfitlife.appfitlife.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.appfitlife.appfitlife.AuthViewModel
import com.appfitlife.appfitlife.ProfileViewModel

class ViewModelFactory(private val userRepository: UserRepository, private val routineDao: RoutineDao, private val mealPlanDao: MealPlanDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AuthViewModel(userRepository) as T
        }
        if (modelClass.isAssignableFrom(ProfileViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProfileViewModel(userRepository, routineDao, mealPlanDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
