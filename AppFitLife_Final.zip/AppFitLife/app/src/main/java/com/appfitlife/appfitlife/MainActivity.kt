package com.appfitlife.appfitlife

import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import coil.compose.rememberAsyncImagePainter
import com.appfitlife.appfitlife.data.*
import com.appfitlife.appfitlife.ui.theme.*
import kotlinx.coroutines.launch

// --- Navigation Sealed Class ---
sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Profile : Screen("profile", "Perfil", Icons.Default.Person)
    object Routines : Screen("routines", "Rutinas", Icons.Default.FitnessCenter)
    object Meals : Screen("meals", "Comidas", Icons.Default.Restaurant)
}

val bottomNavItems = listOf(
    Screen.Profile,
    Screen.Routines,
    Screen.Meals
)

class MainActivity : ComponentActivity() {
    private val authViewModel: AuthViewModel by viewModels { ViewModelFactory(application) }
    private val profileViewModel: ProfileViewModel by viewModels { ViewModelFactory(application) }

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { profileViewModel.updateUserImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppFitLifeTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppFitLifeApp(authViewModel, profileViewModel) { selectImageLauncher.launch("image/*") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppFitLifeApp(authViewModel: AuthViewModel, profileViewModel: ProfileViewModel, onUpdateImage: () -> Unit) {
    val navController = rememberNavController()
    val authResult by authViewModel.authResult.collectAsState(initial = null)
    val loggedInUserId by authViewModel.loggedInUserId.collectAsState()

    LaunchedEffect(authResult) {
        if (authResult is AuthResult.Success) {
            navController.navigate(Screen.Profile.route) { 
                popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
            }
        } else if (authResult is AuthResult.LoggedOut) {
            navController.navigate("login") {
                popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
            }
        }
    }

    if (loggedInUserId != null) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDestination = navBackStackEntry?.destination
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = null) },
                            label = { Text(screen.label) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(navController, startDestination = Screen.Profile.route, Modifier.padding(innerPadding)) {
                composable(Screen.Profile.route) { ProfileScreen(profileViewModel, loggedInUserId!!, onLogout = { authViewModel.logout() }, onUpdateImage = onUpdateImage) }
                composable(Screen.Routines.route) { MyRoutinesScreen(profileViewModel, loggedInUserId!!) }
                composable(Screen.Meals.route) { MyMealPlansScreen(profileViewModel, loggedInUserId!!) }
            }
        }
    } else {
        NavHost(navController = navController, startDestination = "login") {
             composable("login") { LoginScreen(navController, authViewModel) }
             composable("register") { RegisterScreen(navController, authViewModel) }
             composable("forgot_password") { ForgotPasswordScreen(navController, authViewModel) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: ProfileViewModel, userId: String, onLogout: () -> Unit, onUpdateImage: () -> Unit) {
    LaunchedEffect(userId) { viewModel.initializeUserProfile(userId) }

    val userProfileState by viewModel.userProfile.collectAsState()
    val user = userProfileState.user
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = { TopAppBar(title = { Text("Tu Perfil") }) }
    ) {
        if (user != null) {
            var showEditNameDialog by remember { mutableStateOf(false) }
            var showGoalDialog by remember { mutableStateOf(false) }
            var showAllergiesDialog by remember { mutableStateOf(false) }

            LazyColumn(modifier = Modifier.padding(it).padding(16.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                item { ProfileHeader(user, onUpdateImage) { showEditNameDialog = true } }
                item { BmiCard(user, viewModel) }
                item { SetGoalCard() { showGoalDialog = true } }
                item { AllergiesCard { showAllergiesDialog = true } }
            }

            if (showEditNameDialog) {
                EditNameDialog(user = user, onDismiss = { showEditNameDialog = false }) { newName ->
                    viewModel.updateUserName(newName)
                    showEditNameDialog = false
                }
            }

            if (showGoalDialog) {
                var targetWeight by remember { mutableStateOf(user.weight?.toString() ?: "") }
                var goalDate by remember { mutableStateOf<String?>(null) }
                SetGoalDialog(targetWeight, { targetWeight = it; goalDate = viewModel.calculateWeightGoalDate(user.weight?.toFloat() ?: 0f, it.toFloatOrNull() ?: 0f) }, { showGoalDialog = false }, {
                    val message = viewModel.setWeightGoalAndGeneratePlan(user, targetWeight.toFloatOrNull() ?: 0f)
                    scope.launch { snackbarHostState.showSnackbar(message) }
                    showGoalDialog = false
                }, goalDate)
            }

            if (showAllergiesDialog) {
                ExcludedFoodsDialog(user.excludedFoods ?: emptyList(), {
                    showAllergiesDialog = false
                }) { newExcludedFoods ->
                    viewModel.updateUserExcludedFoods(newExcludedFoods)
                    showAllergiesDialog = false
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyRoutinesScreen(viewModel: ProfileViewModel, userId: String) {
    LaunchedEffect(userId) { viewModel.initializeUserProfile(userId) }
    val userProfileState by viewModel.userProfile.collectAsState()
    val routines = userProfileState.routines.groupBy { it.routine.name.substringBefore(" - ").trim() }

    Scaffold(topBar = { TopAppBar(title = { Text("Mis Rutinas") }) }) {
        LazyColumn(modifier = Modifier.padding(it).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (routines.isEmpty() && userProfileState.initialSetupDone) {
                item { Text("No tienes rutinas todavía. ¡Establece una meta en tu perfil para empezar!", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp)) }
            }
            routines.forEach { (day, routinesForDay) ->
                item { Text(day, style = MaterialTheme.typography.headlineMedium, color = Primary, modifier = Modifier.padding(vertical = 8.dp)) }
                items(routinesForDay) { routine ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(routine.routine.name.substringAfter(" - ").trim(), style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            routine.exercises.forEach { exercise ->
                                Text("\u2022 ${exercise.name}: ${exercise.reps}", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyMealPlansScreen(viewModel: ProfileViewModel, userId: String) {
    LaunchedEffect(userId) { viewModel.initializeUserProfile(userId) }
    val userProfileState by viewModel.userProfile.collectAsState()
    val mealPlans = userProfileState.mealPlans.groupBy { it.mealPlan.name.substringBefore(" - ").trim() }

    Scaffold(topBar = { TopAppBar(title = { Text("Mis Planes de Comida") }) }) {
        LazyColumn(modifier = Modifier.padding(it).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (mealPlans.isEmpty() && userProfileState.initialSetupDone) {
                item { Text("No tienes planes de comida. ¡Establece una meta en tu perfil para empezar!", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp)) }
            }
            mealPlans.forEach { (day, plansForDay) ->
                item { Text(day, style = MaterialTheme.typography.headlineMedium, color = Secondary, modifier = Modifier.padding(vertical = 8.dp)) }
                
                plansForDay.groupBy { it.mealPlan.name.substringAfter(" - ").trim() }.forEach { (mealType, plans) ->
                     item {
                        Card(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(mealType, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.height(8.dp))
                                plans.forEach { mealPlan ->
                                    mealPlan.foods.forEach { food ->
                                        Text("\u2022 ${food.name} (${food.calories} kcal)", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileHeader(user: User, onUpdateImage: () -> Unit, onEditName: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Image(
            painter = rememberAsyncImagePainter(model = user.imageUri ?: R.drawable.ic_launcher_foreground),
            contentDescription = "Foto de perfil",
            modifier = Modifier.size(120.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onUpdateImage() },
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1.0f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(user.name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = onEditName, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Edit, "Editar nombre", tint = Secondary) }
            }
            Text(user.email, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun BmiCard(user: User, viewModel: ProfileViewModel) {
    val bmiResult = viewModel.calculateBmiAndWeightGoal(user.weight?.toFloat() ?: 0f, user.height?.toFloat() ?: 0f)
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Tu Progreso (IMC)", style = MaterialTheme.typography.titleLarge, color = Primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("IMC: ${String.format("%.1f", bmiResult.value)} - ${bmiResult.category}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { (bmiResult.value / 40f) }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape))
            Spacer(Modifier.height(12.dp))
            Text(bmiResult.weightGoalMsg, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun SetGoalCard(onSetGoalClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSetGoalClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.background(Brush.horizontalGradient(listOf(GradientStart, Accent))).padding(24.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("¿Listo para un nuevo reto?", style = MaterialTheme.typography.headlineSmall, color = OnPrimary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Define un nuevo peso y generaremos un plan completo para ti.", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge, color = OnPrimary)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onSetGoalClick, colors = ButtonDefaults.buttonColors(containerColor = Secondary)) { Text("Establecer Meta de Peso", color = OnSecondary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun AllergiesCard(onManageClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onManageClick), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.NoFood, "Gestionar alergias", modifier = Modifier.size(40.dp), tint = Error)
            Spacer(Modifier.width(16.dp))
            Column {
                Text("Alergias y Preferencias", style = MaterialTheme.typography.titleLarge)
                Text("Gestiona los alimentos a excluir de tus planes", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun ExcludedFoodsDialog(currentExcluded: List<String>, onDismiss: () -> Unit, onConfirm: (List<String>) -> Unit) {
    var text by remember { mutableStateOf("") }
    val excluded = remember { mutableStateListOf<String>().also { it.addAll(currentExcluded) } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Gestionar Alimentos Excluidos") },
        text = {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Añadir alimento") }, modifier = Modifier.weight(1.0f))
                    IconButton(onClick = { if (text.isNotBlank()) { excluded.add(text); text = "" } }) {
                        Icon(Icons.Default.AddCircle, "Añadir")
                    }
                }
                Spacer(Modifier.height(16.dp))
                LazyColumn {
                    items(excluded) { food ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(food, modifier = Modifier.weight(1f))
                            IconButton(onClick = { excluded.remove(food) }) {
                                Icon(Icons.Default.RemoveCircle, "Quitar")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onConfirm(excluded.toList()) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun EditNameDialog(user: User, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var newUsername by remember { mutableStateOf(user.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cambiar nombre") },
        text = { OutlinedTextField(value = newUsername, onValueChange = { newUsername = it }, label = { Text("Nuevo nombre de usuario") }) },
        confirmButton = { Button(onClick = { onConfirm(newUsername) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun SetGoalDialog(targetWeight: String, onTargetWeightChange: (String) -> Unit, onDismiss: () -> Unit, onConfirm: () -> Unit, goalDate: String?) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Establecer Meta de Peso") },
        text = {
            Column {
                OutlinedTextField(value = targetWeight, onValueChange = onTargetWeightChange, label = { Text("Peso deseado (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                goalDate?.let {
                    Spacer(Modifier.height(16.dp))
                    Text(it, style = MaterialTheme.typography.bodyLarge)
                }
            }
        },
        confirmButton = { Button(onClick = onConfirm) { Text("Generar Plan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun LoginScreen(navController: NavController, viewModel: AuthViewModel) {
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val authResult by viewModel.authResult.collectAsState(initial = null)
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(authResult) {
        (authResult as? AuthResult.Failure)?.let { errorMessage = it.message }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        item {
            Text("Iniciar Sesión", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(32.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre de usuario") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(modifier = Modifier.height(16.dp))
            PasswordTextField(value = password, onValueChange = { password = it }, label = "Contraseña", modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { navController.navigate("forgot_password") }) {
                Text("¿Olvidó su contraseña?")
            }
            Spacer(modifier = Modifier.height(16.dp))
            errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(onClick = { viewModel.login(name, password) }, modifier = Modifier.fillMaxWidth()) { Text("Entrar") }
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { navController.navigate("register") }) { Text("¿No tienes cuenta? Regístrate") }
        }
    }
}

@Composable
fun ForgotPasswordScreen(navController: NavController, viewModel: AuthViewModel) {
    var email by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Recuperar Contraseña", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Ingresa tu correo electrónico y te enviaremos un enlace para restablecer tu contraseña.", textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(32.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(modifier = Modifier.height(16.dp))
        message?.let {
            Text(it, color = if (it.contains("Error")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
        }
        Button(
            onClick = {
                if (Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    message = "Se ha enviado un correo de recuperación a $email"
                } else {
                    message = "Error: Por favor, introduce un email válido."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Enviar")
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(onClick = { navController.popBackStack() }) {
            Text("Volver a Iniciar Sesión")
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(navController: NavController, viewModel: AuthViewModel) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var genderError by remember { mutableStateOf<String?>(null) }
    var weightError by remember { mutableStateOf<String?>(null) }
    var heightError by remember { mutableStateOf<String?>(null) }
    var ageError by remember { mutableStateOf<String?>(null) }

    var genderMenuExpanded by remember { mutableStateOf(false) }
    val genderOptions = listOf("Masculino", "Femenino", "Otro")

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val authResult by viewModel.authResult.collectAsState(initial = null)

    LaunchedEffect(authResult) {
        when (val result = authResult) {
            is AuthResult.Success -> navController.navigate("login") { popUpTo("login") { inclusive = true } }
            is AuthResult.Failure -> nameError = result.message
            else -> {}
        }
        viewModel.clearAuthResult()
    }

    fun validateFields(): Boolean {
        nameError = if (name.isBlank()) "El nombre es obligatorio" else null
        emailError = if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) "Email inválido" else null
        passwordError = if (password.length < 6) "Mínimo 6 caracteres" else null
        genderError = if (gender.isBlank()) "Debes seleccionar un género" else null
        weightError = if (weight.toDoubleOrNull() == null) "Debe ser un número" else null
        heightError = if (height.toDoubleOrNull() == null) "Debe ser un número" else null
        ageError = if (age.toIntOrNull() == null) "Debe ser un número" else null
        return nameError == null && emailError == null && passwordError == null && genderError == null && weightError == null && heightError == null && ageError == null
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(it).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Text("Crear Cuenta", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre de usuario") }, modifier = Modifier.fillMaxWidth(), singleLine = true, isError = nameError != null, supportingText = { nameError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = emailError != null, supportingText = { emailError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                PasswordTextField(value = password, onValueChange = { password = it }, label = "Contraseña", modifier = Modifier.fillMaxWidth(), isError = passwordError != null, supportingText = { passwordError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                ExposedDropdownMenuBox(
                    expanded = genderMenuExpanded,
                    onExpandedChange = { genderMenuExpanded = !genderMenuExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = gender,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Sexo") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = genderMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        isError = genderError != null,
                        supportingText = { genderError?.let { Text(it, color = MaterialTheme.colorScheme.error) } }
                    )
                    ExposedDropdownMenu(
                        expanded = genderMenuExpanded,
                        onDismissRequest = { genderMenuExpanded = false }
                    ) {
                        genderOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    gender = option
                                    genderMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = weight, onValueChange = { weight = it }, label = { Text("Peso (kg)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = weightError != null, supportingText = { weightError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = height, onValueChange = { height = it }, label = { Text("Altura (cm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = heightError != null, supportingText = { heightError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Edad") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true, isError = ageError != null, supportingText = { ageError?.let { Text(it, color = MaterialTheme.colorScheme.error) } })
                Spacer(modifier = Modifier.height(24.dp))

                Button(onClick = {
                    if (validateFields()) {
                        viewModel.register(name, email, password, age, weight, height, gender)
                    } else {
                        scope.launch { snackbarHostState.showSnackbar("Faltan campos por completar o son incorrectos") }
                    }
                }) {
                    Text("Registrarse")
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = { navController.navigate("login") }) {
                    Text("¿Ya tienes cuenta? Inicia Sesión")
                }
            }
        }
    }
}

@Composable
fun PasswordTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    isError: Boolean = false,
    supportingText: @Composable (() -> Unit)? = null
) {
    var passwordVisibility by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        isError = isError,
        supportingText = supportingText,
        visualTransformation = if (passwordVisibility) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            val image = if (passwordVisibility) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
            val description = if (passwordVisibility) "Ocultar contraseña" else "Mostrar contraseña"
            IconButton(onClick = { passwordVisibility = !passwordVisibility }) {
                Icon(imageVector = image, contentDescription = description)
            }
        }
    )
}
