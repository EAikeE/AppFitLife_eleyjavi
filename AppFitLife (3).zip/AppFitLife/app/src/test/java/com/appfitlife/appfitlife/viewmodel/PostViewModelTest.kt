package com.appfitlife.appfitlife.viewmodel

import com.appfitlife.appfitlife.data.model.Post
import com.appfitlife.appfitlife.repository.PostRepository
import io.kotest.core.spec.style.StringSpec
import io.kotest.matchers.shouldBe
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain

@ExperimentalCoroutinesApi
class PostViewModelTest : StringSpec({

    val testDispatcher = StandardTestDispatcher()
    lateinit var repository: PostRepository

    beforeTest {
        Dispatchers.setMain(testDispatcher)
        repository = mockk()
    }

    afterTest {
        Dispatchers.resetMain()
    }

    "posts should be fetched on init and reflect success" { 
        runTest {
            // Given
            val expectedPosts = listOf(Post(1, 1, "title", "body"))
            coEvery { repository.getPosts() } returns expectedPosts

            // When
            val viewModel = PostViewModel(repository)

            // Then
            testDispatcher.scheduler.advanceUntilIdle() // Ejecuta las coroutines pendientes
            viewModel.posts.value shouldBe expectedPosts
        }
    }

    "posts should be empty list on repository error" {
        runTest {
            // Given
            coEvery { repository.getPosts() } throws Exception("Network Error")

            // When
            val viewModel = PostViewModel(repository)

            // Then
            testDispatcher.scheduler.advanceUntilIdle()
            viewModel.posts.value shouldBe emptyList()
        }
    }
})