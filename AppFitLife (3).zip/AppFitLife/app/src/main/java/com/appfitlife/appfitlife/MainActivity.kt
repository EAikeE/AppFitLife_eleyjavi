package com.appfitlife.appfitlife

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.appfitlife.appfitlife.ui.theme.AppFitLifeTheme
import com.appfitlife.appfitlife.viewmodel.AuthViewModel
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

class MainActivity : ComponentActivity() {
    private val authViewModel: AuthViewModel by viewModels { ViewModelFactory(application) }
    private val profileViewModel: ProfileViewModel by viewModels { ViewModelFactory(application) }

    private val selectImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { profileViewModel.updateUserImage(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppFitLifeTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppFitLifeApp(authViewModel, profileViewModel) { selectImageLauncher.launch("image/*") }
                }
            }
        }
    }
}