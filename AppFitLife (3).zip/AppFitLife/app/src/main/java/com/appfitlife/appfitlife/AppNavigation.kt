package com.appfitlife.appfitlife

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.appfitlife.appfitlife.data.AuthResult
import com.appfitlife.appfitlife.ui.screens.PostScreen
import com.appfitlife.appfitlife.ui.screens.auth.ForgotPasswordScreen
import com.appfitlife.appfitlife.ui.screens.auth.LoginScreen
import com.appfitlife.appfitlife.ui.screens.auth.RegisterScreen
import com.appfitlife.appfitlife.ui.screens.meals.MyMealPlansScreen
import com.appfitlife.appfitlife.ui.screens.profile.ProfileScreen
import com.appfitlife.appfitlife.ui.screens.routines.MyRoutinesScreen
import com.appfitlife.appfitlife.viewmodel.AuthViewModel
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Profile : Screen("profile", "Perfil", Icons.Default.Person)
    object Routines : Screen("routines", "Rutinas", Icons.Default.FitnessCenter)
    object Meals : Screen("meals", "Comidas", Icons.Default.Restaurant)
    object Posts : Screen("posts", "Posts", Icons.Default.List)
}

val bottomNavItems = listOf(
    Screen.Profile,
    Screen.Routines,
    Screen.Meals,
    Screen.Posts
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppFitLifeApp(authViewModel: AuthViewModel, profileViewModel: ProfileViewModel, onUpdateImage: () -> Unit) {
    val navController = rememberNavController()
    val authResult by authViewModel.authResult.collectAsState(initial = null)
    val loggedInUserId by authViewModel.loggedInUserId.collectAsState()

    LaunchedEffect(authResult) {
        if (authResult is AuthResult.Success) {
            navController.navigate(Screen.Profile.route) {
                popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
            }
        } else if (authResult is AuthResult.LoggedOut) {
            navController.navigate("login") {
                popUpTo(navController.graph.findStartDestination().id) { inclusive = true }
            }
        }
    }

    if (loggedInUserId != null) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentDestination = navBackStackEntry?.destination
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = null) },
                            label = { Text(screen.label) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(navController, startDestination = Screen.Profile.route, Modifier.padding(innerPadding)) {
                composable(Screen.Profile.route) { ProfileScreen(profileViewModel, loggedInUserId!!, onLogout = { authViewModel.logout() }, onUpdateImage = onUpdateImage) }
                composable(Screen.Routines.route) { MyRoutinesScreen(profileViewModel, loggedInUserId!!) }
                composable(Screen.Meals.route) { MyMealPlansScreen(profileViewModel, loggedInUserId!!) }
                composable(Screen.Posts.route) { PostScreen() }
            }
        }
    } else {
        NavHost(navController = navController, startDestination = "login") {
             composable("login") { LoginScreen(navController, authViewModel) }
             composable("register") { RegisterScreen(navController, authViewModel) }
             composable("forgot_password") { ForgotPasswordScreen(navController, authViewModel) }
        }
    }
}