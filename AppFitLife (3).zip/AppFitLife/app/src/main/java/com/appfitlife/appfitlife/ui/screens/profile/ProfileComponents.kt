package com.appfitlife.appfitlife.ui.screens.profile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.NoFood
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.appfitlife.appfitlife.R
import com.appfitlife.appfitlife.data.User
import com.appfitlife.appfitlife.ui.theme.*
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

@Composable
fun ProfileHeader(user: User, onUpdateImage: () -> Unit, onEditName: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Image(
            painter = rememberAsyncImagePainter(model = user.imageUri ?: R.drawable.ic_launcher_foreground),
            contentDescription = "Foto de perfil",
            modifier = Modifier.size(120.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onUpdateImage() },
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1.0f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(user.name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                IconButton(onClick = onEditName, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Edit, "Editar nombre", tint = Secondary) }
            }
            Text(user.email, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun BmiCard(user: User, viewModel: ProfileViewModel) {
    val bmiResult = viewModel.calculateBmiAndWeightGoal(user.weight?.toFloat() ?: 0f, user.height?.toFloat() ?: 0f)
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Tu Progreso (IMC)", style = MaterialTheme.typography.titleLarge, color = Primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("IMC: ${String.format("%.1f", bmiResult.value)} - ${bmiResult.category}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = bmiResult.value / 40f, modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape))
            Spacer(Modifier.height(12.dp))
            Text(bmiResult.weightGoalMsg, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun SetGoalCard(onSetGoalClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSetGoalClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier.background(Brush.horizontalGradient(listOf(GradientStart, Accent))).padding(24.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("¿Listo para un nuevo reto?", style = MaterialTheme.typography.headlineSmall, color = OnPrimary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Define un nuevo peso y generaremos un plan completo para ti.", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge, color = OnPrimary)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onSetGoalClick, colors = ButtonDefaults.buttonColors(containerColor = Secondary)) { Text("Establecer Meta de Peso", color = OnSecondary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun AllergiesCard(onManageClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onManageClick), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.NoFood, "Gestionar alergias", modifier = Modifier.size(40.dp), tint = Error)
            Spacer(Modifier.width(16.dp))
            Column {
                Text("Alergias y Preferencias", style = MaterialTheme.typography.titleLarge)
                Text("Gestiona los alimentos a excluir de tus planes", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}