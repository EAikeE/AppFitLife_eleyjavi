package com.appfitlife.appfitlife.data.model

data class Post(
    val userId: Int,
    val id: Int,
    val title: String,
    val body: String
)