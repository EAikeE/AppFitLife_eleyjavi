package com.appfitlife.appfitlife.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appfitlife.appfitlife.data.AuthResult
import com.appfitlife.appfitlife.data.User
import com.appfitlife.appfitlife.data.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AuthViewModel(private val userRepository: UserRepository) : ViewModel() {
    private val _authResult = MutableStateFlow<AuthResult?>(null)
    val authResult: StateFlow<AuthResult?> = _authResult.asStateFlow()

    private val _loggedInUserId = MutableStateFlow<String?>(null)
    val loggedInUserId: StateFlow<String?> = _loggedInUserId.asStateFlow()

    fun login(name: String, password: String) {
        viewModelScope.launch {
            val user = userRepository.getUserByName(name)
            if (user != null && user.password == password) {
                _loggedInUserId.value = user.id
                _authResult.value = AuthResult.Success(user)
            } else {
                _authResult.value = AuthResult.Failure("Usuario no encontrado o contraseña incorrecta.")
            }
        }
    }

    fun register(name: String, email: String, password: String, ageStr: String, weightStr: String, heightStr: String, gender: String) {
        viewModelScope.launch {
            if (userRepository.getUserByName(name) != null) {
                _authResult.value = AuthResult.Failure("El nombre de usuario ya existe.")
                return@launch
            }
            val newUser = User(
                id = UUID.randomUUID().toString(), 
                name = name, 
                email = email,
                password = password,
                age = ageStr.toIntOrNull(), 
                weight = weightStr.toDoubleOrNull(), 
                height = heightStr.toDoubleOrNull(),
                imageUri = null, 
                gender = gender,
                excludedFoods = emptyList(),
                targetWeight = null
            )
            userRepository.insertUser(newUser)
            _loggedInUserId.value = newUser.id
            _authResult.value = AuthResult.Success(newUser)
        }
    }

    fun logout() {
        _loggedInUserId.value = null
        _authResult.value = AuthResult.LoggedOut
    }

    fun clearAuthResult() {
        _authResult.value = null
    }
}