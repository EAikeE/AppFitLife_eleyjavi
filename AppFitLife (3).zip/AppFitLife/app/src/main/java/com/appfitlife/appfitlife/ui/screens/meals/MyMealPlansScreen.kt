package com.appfitlife.appfitlife.ui.screens.meals

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.appfitlife.appfitlife.ui.theme.Secondary
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyMealPlansScreen(viewModel: ProfileViewModel, userId: String) {
    LaunchedEffect(userId) { viewModel.initializeUserProfile(userId) }
    val userProfileState by viewModel.userProfile.collectAsState()
    val mealPlans = userProfileState.mealPlans.groupBy { it.mealPlan.name.substringBefore(" - ").trim() }

    Scaffold(topBar = { TopAppBar(title = { Text("Mis Planes de Comida") }) }) {
        LazyColumn(modifier = Modifier.padding(it).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (mealPlans.isEmpty() && userProfileState.initialSetupDone) {
                item { Text("No tienes planes de comida. ¡Establece una meta en tu perfil para empezar!", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp)) }
            }
            mealPlans.forEach { (day, plansForDay) ->
                item { Text(day, style = MaterialTheme.typography.headlineMedium, color = Secondary, modifier = Modifier.padding(vertical = 8.dp)) }
                
                plansForDay.groupBy { it.mealPlan.name.substringAfter(" - ").trim() }.forEach { (mealType, plans) ->
                     item {
                        Card(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(mealType, style = MaterialTheme.typography.titleLarge)
                                Spacer(Modifier.height(8.dp))
                                plans.forEach { mealPlan ->
                                    mealPlan.foods.forEach { food ->
                                        Text("\u2022 ${food.name} (${food.calories} kcal)", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}