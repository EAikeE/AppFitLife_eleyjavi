package com.appfitlife.appfitlife.data

fun getPredefinedExercises(): List<Exercise> = listOf(
    Exercise(name = "Correr en cinta", description = "Cardio", sets = "1", reps = "30 min"),
    Exercise(name = "Plancha", description = "Core", sets = "4", reps = "45s"),
    Exercise(name = "Burpees", description = "Full Body", sets = "3", reps = "12 reps"),
    Exercise(name = "Flexiones", description = "Pecho, Hombros, Tríceps", sets = "4", reps = "Al fallo"),
    Exercise(name = "Remo con mancuerna", description = "Espalda, Bíceps", sets = "4", reps = "12 reps por brazo"),
    Exercise(name = "Press de hombros", description = "Hombros", sets = "3", reps = "15 reps"),
    Exercise(name = "Caminata ligera", description = "Cardio", sets = "1", reps = "45 min"),
    Exercise(name = "Estiramientos", description = "Flexibilidad", sets = "1", reps = "15 min"),
    Exercise(name = "Sentadillas", description = "Piernas, Glúteos", sets = "4", reps = "15 reps"),
    Exercise(name = "Zancadas", description = "Piernas, Glúteos", sets = "3", reps = "12 reps por pierna"),
    Exercise(name = "Elevación de cadera", description = "Glúteos, Isquiotibiales", sets = "4", reps = "20 reps"),
    Exercise(name = "Saltar la cuerda", description = "Cardio", sets = "1", reps = "20 min (1 min on / 30s off)"),
    Exercise(name = "Mountain Climbers", description = "Core, Cardio", sets = "4", reps = "30s"),
    Exercise(name = "Jumping Jacks", description = "Cardio", sets = "4", reps = "45s"),
    Exercise(name = "Peso muerto", description = "Full Body, Espalda baja", sets = "3", reps = "10 reps"),
    Exercise(name = "Press de banca", description = "Pecho, Hombros, Tríceps", sets = "4", reps = "8-10 reps"),
    Exercise(name = "Fondos en paralelas", description = "Pecho, Tríceps", sets = "4", reps = "10 reps"),
    Exercise(name = "Press francés", description = "Tríceps", sets = "3", reps = "12 reps"),
    Exercise(name = "Dominadas", description = "Espalda, Bíceps", sets = "4", reps = "Al fallo"),
    Exercise(name = "Remo con barra", description = "Espalda, Bíceps", sets = "4", reps = "8 reps"),
    Exercise(name = "Curl de bíceps con barra", description = "Bíceps", sets = "4", reps = "10 reps"),
    Exercise(name = "Prensa", description = "Piernas", sets = "4", reps = "10 reps"),
    Exercise(name = "Press militar", description = "Hombros", sets = "4", reps = "10 reps"),
    Exercise(name = "Elevaciones laterales", description = "Hombros", sets = "4", reps = "12 reps"),
    Exercise(name = "Plancha con peso", description = "Core", sets = "4", reps = "60s")
)

fun getPredefinedFoodItems(): List<FoodItem> = listOf(
    FoodItem(name = "Avena con frutas", calories = 350),
    FoodItem(name = "Té verde", calories = 1),
    FoodItem(name = "Pechuga de Pollo a la plancha", calories = 220),
    FoodItem(name = "Ensalada de hojas verdes", calories = 50),
    FoodItem(name = "Quinoa", calories = 120),
    FoodItem(name = "Sopa de verduras", calories = 150),
    FoodItem(name = "Yogur Griego", calories = 100),
    FoodItem(name = "Revoltillo de claras", calories = 150),
    FoodItem(name = "Pan integral", calories = 80),
    FoodItem(name = "Salmón al horno", calories = 300),
    FoodItem(name = "Brócoli al vapor", calories = 55),
    FoodItem(name = "Ensalada de atún", calories = 200),
    FoodItem(name = "Galletas integrales", calories = 120),
    FoodItem(name = "Yogur natural con frutos secos", calories = 250),
    FoodItem(name = "Lentejas guisadas", calories = 350),
    FoodItem(name = "Arroz integral", calories = 110),
    FoodItem(name = "Pavo a la plancha", calories = 190),
    FoodItem(name = "Ensalada de pepino y tomate", calories = 60),
    FoodItem(name = "Batido de proteínas", calories = 180),
    FoodItem(name = "Plátano", calories = 105),
    FoodItem(name = "Garbanzos con espinacas", calories = 300),
    FoodItem(name = "Huevo duro", calories = 78),
    FoodItem(name = "Merluza a la plancha", calories = 200),
    FoodItem(name = "Puré de calabaza", calories = 90),
    FoodItem(name = "Tostadas integrales con aguacate", calories = 250),
    FoodItem(name = "Filete de ternera magra", calories = 250),
    FoodItem(name = "Pimientos asados", calories = 70),
    FoodItem(name = "Crema de zanahoria", calories = 130),
    FoodItem(name = "Queso fresco", calories = 98),
    FoodItem(name = "Pollo al horno con hierbas", calories = 240),
    FoodItem(name = "Ensalada mixta", calories = 100),
    FoodItem(name = "Ensalada César (versión ligera)", calories = 250),
    FoodItem(name = "Comida libre moderada", calories = 600),
    FoodItem(name = "Avena con leche entera y plátano", calories = 450),
    FoodItem(name = "Nueces", calories = 200),
    FoodItem(name = "Pasta con carne molida", calories = 550),
    FoodItem(name = "Queso parmesano", calories = 50),
    FoodItem(name = "Arroz blanco", calories = 130),
    FoodItem(name = "Aguacate", calories = 234),
    FoodItem(name = "Huevos enteros revueltos", calories = 300),
    FoodItem(name = "Tostadas con mantequilla", calories = 250),
    FoodItem(name = "Batata asada", calories = 180),
    FoodItem(name = "Filete de ternera", calories = 300),
    FoodItem(name = "Puré de patatas", calories = 200),
    FoodItem(name = "Yogur griego con miel y granola", calories = 350),
    FoodItem(name = "Frutos secos", calories = 200),
    FoodItem(name = "Lentejas con chorizo", calories = 450),
    FoodItem(name = "Pan", calories = 100),
    FoodItem(name = "Pavo guisado", calories = 250),
    FoodItem(name = "Arroz con vegetales", calories = 180),
    FoodItem(name = "Batido hipercalórico", calories = 600),
    FoodItem(name = "Tostada con crema de cacahuete", calories = 220),
    FoodItem(name = "Hamburguesa casera con queso", calories = 500),
    FoodItem(name = "Patatas al horno", calories = 200),
    FoodItem(name = "Pescado azul al horno", calories = 280),
    FoodItem(name = "Pasta carbonara", calories = 600),
    FoodItem(name = "Bacon", calories = 150),
    FoodItem(name = "Pollo asado", calories = 300),
    FoodItem(name = "Ensalada de patata", calories = 250),
    FoodItem(name = "Pizza casera", calories = 400),
    FoodItem(name = "Lasagna de carne", calories = 500)
)

fun getWeightLossRoutineMap(): Map<String, Pair<String, Map<String, String>>> = mapOf(
    "Lunes" to ("Cardio y Core" to mapOf("Correr en cinta" to "30 min a 6-7 km/h", "Plancha" to "4 series de 45s", "Burpees" to "3 series de 12 reps")),
    "Martes" to ("Fuerza - Tren Superior" to mapOf("Flexiones" to "4 series al fallo", "Remo con mancuerna" to "4 series de 12 reps por brazo", "Press de hombros" to "3 series de 15 reps")),
    "Miércoles" to ("Descanso Activo" to mapOf("Caminata ligera" to "45 minutos", "Estiramientos" to "15 minutos")),
    "Jueves" to ("Fuerza - Tren Inferior" to mapOf("Sentadillas" to "4 series de 15 reps", "Zancadas" to "3 series de 12 reps por pierna", "Elevación de cadera" to "4x20 reps")),
    "Viernes" to ("HIIT" to mapOf("Saltar la cuerda" to "20 min (1 min on / 30s off)", "Mountain Climbers" to "4 series de 30s", "Jumping Jacks" to "4 series de 45s")),
    "Sábado" to ("Full Body" to mapOf("Peso muerto" to "3x10 reps", "Flexiones" to "3x max reps", "Sentadillas" to "3x15 reps")),
    "Domingo" to ("Descanso" to emptyMap())
)

fun getWeightLossMealMap(): Map<String, Map<String, List<Pair<String, String>>>> = mapOf(
    "Lunes" to mapOf(
        "Desayuno" to listOf("Avena con frutas" to "1 taza", "Té verde" to "1 taza"),
        "Almuerzo" to listOf("Pechuga de Pollo a la plancha" to "150g", "Ensalada de hojas verdes" to "2 tazas", "Quinoa" to "1/2 taza"),
        "Cena" to listOf("Sopa de verduras" to "1 plato hondo", "Yogur Griego" to "1 taza")
    ),
    "Martes" to mapOf(
        "Desayuno" to listOf("Revoltillo de claras" to "3 claras", "Pan integral" to "1 rebanada"),
        "Almuerzo" to listOf("Salmón al horno" to "180g", "Brócoli al vapor" to "1.5 tazas"),
        "Cena" to listOf("Ensalada de atún" to "1 lata en agua", "Galletas integrales" to "4 unidades")
    ),
    "Miércoles" to mapOf(
        "Desayuno" to listOf("Yogur natural con frutos secos" to "1 taza, 30g frutos secos"),
        "Almuerzo" to listOf("Lentejas guisadas" to "1.5 tazas", "Arroz integral" to "1/4 taza"),
        "Cena" to listOf("Pavo a la plancha" to "150g", "Ensalada de pepino y tomate" to "1 taza")
    ),
    "Jueves" to mapOf(
        "Desayuno" to listOf("Batido de proteínas" to "1 scoop", "Plátano" to "1 unidad"),
        "Almuerzo" to listOf("Garbanzos con espinacas" to "1.5 tazas", "Huevo duro" to "1 unidad"),
        "Cena" to listOf("Merluza a la plancha" to "200g", "Puré de calabaza" to "1 taza")
    ),
    "Viernes" to mapOf(
        "Desayuno" to listOf("Tostadas integrales con aguacate" to "2 rebanadas, 1/2 aguacate"),
        "Almuerzo" to listOf("Filete de ternera magra" to "150g", "Pimientos asados" to "1 taza"),
        "Cena" to listOf("Crema de zanahoria" to "1 plato", "Queso fresco" to "100g")
    ),
    "Sábado" to mapOf(
        "Desayuno" to listOf("Avena con frutas" to "1 taza", "Té verde" to "1 taza"),
        "Almuerzo" to listOf("Pollo al horno con hierbas" to "180g", "Ensalada mixta" to "2 tazas"),
        "Cena" to listOf("Ensalada César (versión ligera)" to "1 plato")
    ),
    "Domingo" to mapOf(
        "Desayuno" to listOf("Revoltillo de claras" to "3 claras", "Pan integral" to "1 rebanada"),
        "Almuerzo" to listOf("Comida libre moderada" to "1 porción"),
        "Cena" to listOf("Sopa de verduras" to "1 plato hondo")
    )
)

fun getWeightGainRoutineMap(): Map<String, Pair<String, Map<String, String>>> = mapOf(
    "Lunes" to ("Fuerza - Pecho y Tríceps" to mapOf("Press de banca" to "4 series de 8-10 reps", "Fondos en paralelas" to "4 series de 10 reps", "Press francés" to "3x12 reps")),
    "Martes" to ("Fuerza - Espalda y Bíceps" to mapOf("Dominadas" to "4 series al fallo", "Remo con barra" to "4 series de 8 reps", "Curl de bíceps con barra" to "4x10 reps")),
    "Miércoles" to ("Descanso" to emptyMap()),
    "Jueves" to ("Fuerza - Piernas" to mapOf("Sentadillas" to "5 series de 5 reps", "Peso muerto" to "3 series de 5 reps", "Prensa" to "4x10 reps")),
    "Viernes" to ("Fuerza - Hombros y Core" to mapOf("Press militar" to "4 series de 10 reps", "Elevaciones laterales" to "4x12 reps", "Plancha con peso" to "4 series de 60s")),
    "Sábado" to ("Full Body Hypertrophy" to mapOf("Sentadillas" to "3x12 reps", "Press de banca" to "3x12 reps", "Remo con barra" to "3x12 reps")),
    "Domingo" to ("Descanso" to emptyMap())
)

fun getWeightGainMealMap(): Map<String, Map<String, List<Pair<String, String>>>> = mapOf(
    "Lunes" to mapOf(
        "Desayuno" to listOf("Avena con leche entera y plátano" to "1.5 tazas", "Nueces" to "40g"),
        "Almuerzo" to listOf("Pasta con carne molida" to "2 tazas", "Queso parmesano" to "3 cucharadas"),
        "Cena" to listOf("Pechuga de Pollo" to "200g", "Arroz blanco" to "1.5 tazas", "Aguacate" to "1/2 pieza")
    ),
    "Martes" to mapOf(
        "Desayuno" to listOf("Huevos enteros revueltos" to "4 unidades", "Tostadas con mantequilla" to "2 rebanadas"),
        "Almuerzo" to listOf("Salmón a la plancha" to "200g", "Batata asada" to "2 piezas medianas"),
        "Cena" to listOf("Filete de ternera" to "200g", "Puré de patatas" to "1.5 tazas")
    ),
    "Miércoles" to mapOf(
        "Desayuno" to listOf("Yogur griego con miel y granola" to "1.5 tazas", "Frutos secos" to "50g"),
        "Almuerzo" to listOf("Lentejas con chorizo" to "2 tazas", "Pan" to "2 rebanadas"),
        "Cena" to listOf("Pavo guisado" to "200g", "Arroz con vegetales" to "1.5 tazas")
    ),
    "Jueves" to mapOf(
        "Desayuno" to listOf("Batido hipercalórico" to "Leche, plátano, avena, proteína", "Tostada con crema de cacahuete" to "2 rebanadas"),
        "Almuerzo" to listOf("Hamburguesa casera con queso" to "1 unidad", "Patatas al horno" to "1.5 tazas"),
        "Cena" to listOf("Pescado azul al horno" to "200g", "Quinoa" to "1.5 tazas")
    ),
    "Viernes" to mapOf(
        "Desayuno" to listOf("Huevos enteros revueltos" to "4 unidades", "Tostadas con mantequilla" to "2 rebanadas"),
        "Almuerzo" to listOf("Pasta carbonara" to "2 tazas", "Bacon" to "50g"),
        "Cena" to listOf("Pollo asado" to "1/4 de pollo", "Ensalada de patata" to "1.5 tazas")
    ),
    "Sábado" to mapOf(
        "Desayuno" to listOf("Yogur griego con miel y granola" to "1.5 tazas", "Frutos secos" to "50g"),
        "Almuerzo" to listOf("Comida libre alta en calorías" to "1 porción generosa"),
        "Cena" to listOf("Pizza casera" to "2-3 porciones")
    ),
    "Domingo" to mapOf(
        "Desayuno" to listOf("Batido hipercalórico" to "Leche, plátano, avena, proteína", "Tostada con crema de cacahuete" to "2 rebanadas"),
        "Almuerzo" to listOf("Lasagna de carne" to "1 porción grande"),
        "Cena" to listOf("Restos del almuerzo o cena ligera" to "A gusto")
    )
)
