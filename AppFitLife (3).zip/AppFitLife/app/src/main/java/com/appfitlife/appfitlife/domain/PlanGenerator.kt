package com.appfitlife.appfitlife.domain

fun getWeightLossRoutineMap(): Map<String, Pair<String, Map<String, String>>> = mapOf(
    "Lunes" to ("Cardio y Core" to mapOf("Correr en cinta" to "30 min a 6-7 km/h", "Plancha" to "4 series de 45s", "Burpees" to "3 series de 12 reps")),
    "Martes" to ("Fuerza - Tren Superior" to mapOf("Flexiones" to "4 series al fallo", "Remo con mancuerna" to "4 series de 12 reps por brazo", "Press de hombros" to "3 series de 15 reps")),
    "Miércoles" to ("Descanso Activo" to mapOf("Caminata ligera" to "45 minutos", "Estiramientos" to "15 minutos")),
    "Jueves" to ("Fuerza - Tren Inferior" to mapOf("Sentadillas" to "4 series de 15 reps", "Zancadas" to "3 series de 12 reps por pierna", "Elevación de cadera" to "4x20 reps")),
    "Viernes" to ("HIIT" to mapOf("Saltar la cuerda" to "20 min (1 min on / 30s off)", "Mountain Climbers" to "4 series de 30s", "Jumping Jacks" to "4 series de 45s")),
    "Sábado" to ("Full Body" to mapOf("Peso muerto" to "3x10 reps", "Flexiones" to "3x max reps", "Sentadillas" to "3x15 reps")),
    "Domingo" to ("Descanso" to emptyMap())
)

fun getWeightLossMealMap(): Map<String, Map<String, List<Pair<String, String>>>> = mapOf(
    "Lunes" to mapOf(
        "Desayuno" to listOf("Avena con frutas" to "1 taza", "Té verde" to "1 taza"),
        "Almuerzo" to listOf("Pechuga de Pollo a la plancha" to "150g", "Ensalada de hojas verdes" to "2 tazas", "Quinoa" to "1/2 taza"),
        "Cena" to listOf("Sopa de verduras" to "1 plato hondo", "Yogur Griego" to "1 taza")
    ),
    "Martes" to mapOf(
        "Desayuno" to listOf("Revoltillo de claras" to "3 claras", "Pan integral" to "1 rebanada"),
        "Almuerzo" to listOf("Salmón al horno" to "180g", "Brócoli al vapor" to "1.5 tazas"),
        "Cena" to listOf("Ensalada de atún" to "1 lata en agua", "Galletas integrales" to "4 unidades")
    ),
    "Miércoles" to mapOf(
        "Desayuno" to listOf("Yogur natural con frutos secos" to "1 taza, 30g frutos secos"),
        "Almuerzo" to listOf("Lentejas guisadas" to "1.5 tazas", "Arroz integral" to "1/4 taza"),
        "Cena" to listOf("Pavo a la plancha" to "150g", "Ensalada de pepino y tomate" to "1 taza")
    ),
    "Jueves" to mapOf(
        "Desayuno" to listOf("Batido de proteínas" to "1 scoop", "Plátano" to "1 unidad"),
        "Almuerzo" to listOf("Garbanzos con espinacas" to "1.5 tazas", "Huevo duro" to "1 unidad"),
        "Cena" to listOf("Merluza a la plancha" to "200g", "Puré de calabaza" to "1 taza")
    ),
    "Viernes" to mapOf(
        "Desayuno" to listOf("Tostadas integrales con aguacate" to "2 rebanadas, 1/2 aguacate"),
        "Almuerzo" to listOf("Filete de ternera magra" to "150g", "Pimientos asados" to "1 taza"),
        "Cena" to listOf("Crema de zanahoria" to "1 plato", "Queso fresco" to "100g")
    ),
    "Sábado" to mapOf(
        "Desayuno" to listOf("Avena con frutas" to "1 taza", "Té verde" to "1 taza"),
        "Almuerzo" to listOf("Pollo al horno con hierbas" to "180g", "Ensalada mixta" to "2 tazas"),
        "Cena" to listOf("Ensalada César (versión ligera)" to "1 plato")
    ),
    "Domingo" to mapOf(
        "Desayuno" to listOf("Revoltillo de claras" to "3 claras", "Pan integral" to "1 rebanada"),
        "Almuerzo" to listOf("Comida libre moderada" to "1 porción"),
        "Cena" to listOf("Sopa de verduras" to "1 plato hondo")
    )
)

fun getWeightGainRoutineMap(): Map<String, Pair<String, Map<String, String>>> = mapOf(
    "Lunes" to ("Fuerza - Pecho y Tríceps" to mapOf("Press de banca" to "4 series de 8-10 reps", "Fondos en paralelas" to "4 series de 10 reps", "Press francés" to "3x12 reps")),
    "Martes" to ("Fuerza - Espalda y Bíceps" to mapOf("Dominadas" to "4 series al fallo", "Remo con barra" to "4 series de 8 reps", "Curl de bíceps con barra" to "4x10 reps")),
    "Miércoles" to ("Descanso" to emptyMap()),
    "Jueves" to ("Fuerza - Piernas" to mapOf("Sentadillas" to "5 series de 5 reps", "Peso muerto" to "3 series de 5 reps", "Prensa" to "4x10 reps")),
    "Viernes" to ("Fuerza - Hombros y Core" to mapOf("Press militar" to "4 series de 10 reps", "Elevaciones laterales" to "4x12 reps", "Plancha con peso" to "4 series de 60s")),
    "Sábado" to ("Full Body Hypertrophy" to mapOf("Sentadillas" to "3x12 reps", "Press de banca" to "3x12 reps", "Remo con barra" to "3x12 reps")),
    "Domingo" to ("Descanso" to emptyMap())
)

fun getWeightGainMealMap(): Map<String, Map<String, List<Pair<String, String>>>> = mapOf(
    "Lunes" to mapOf(
        "Desayuno" to listOf("Avena con leche entera y plátano" to "1.5 tazas", "Nueces" to "40g"),
        "Almuerzo" to listOf("Pasta con carne molida" to "2 tazas", "Queso parmesano" to "3 cucharadas"),
        "Cena" to listOf("Pechuga de Pollo" to "200g", "Arroz blanco" to "1.5 tazas", "Aguacate" to "1/2 pieza")
    ),
    "Martes" to mapOf(
        "Desayuno" to listOf("Huevos enteros revueltos" to "4 unidades", "Tostadas con mantequilla" to "2 rebanadas"),
        "Almuerzo" to listOf("Salmón a la plancha" to "200g", "Batata asada" to "2 piezas medianas"),
        "Cena" to listOf("Filete de ternera" to "200g", "Puré de patatas" to "1.5 tazas")
    ),
    "Miércoles" to mapOf(
        "Desayuno" to listOf("Yogur griego con miel y granola" to "1.5 tazas", "Frutos secos" to "50g"),
        "Almuerzo" to listOf("Lentejas con chorizo" to "2 tazas", "Pan" to "2 rebanadas"),
        "Cena" to listOf("Pavo guisado" to "200g", "Arroz con vegetales" to "1.5 tazas")
    ),
    "Jueves" to mapOf(
        "Desayuno" to listOf("Batido hipercalórico" to "Leche, plátano, avena, proteína", "Tostada con crema de cacahuete" to "2 rebanadas"),
        "Almuerzo" to listOf("Hamburguesa casera con queso" to "1 unidad", "Patatas al horno" to "1.5 tazas"),
        "Cena" to listOf("Pescado azul al horno" to "200g", "Quinoa" to "1.5 tazas")
    ),
    "Viernes" to mapOf(
        "Desayuno" to listOf("Huevos enteros revueltos" to "4 unidades", "Tostadas con mantequilla" to "2 rebanadas"),
        "Almuerzo" to listOf("Pasta carbonara" to "2 tazas", "Bacon" to "50g"),
        "Cena" to listOf("Pollo asado" to "1/4 de pollo", "Ensalada de patata" to "1.5 tazas")
    ),
    "Sábado" to mapOf(
        "Desayuno" to listOf("Yogur griego con miel y granola" to "1.5 tazas", "Frutos secos" to "50g"),
        "Almuerzo" to listOf("Comida libre alta en calorías" to "1 porción generosa"),
        "Cena" to listOf("Pizza casera" to "2-3 porciones")
    ),
    "Domingo" to mapOf(
        "Desayuno" to listOf("Batido hipercalórico" to "Leche, plátano, avena, proteína", "Tostada con crema de cacahuete" to "2 rebanadas"),
        "Almuerzo" to listOf("Lasagna de carne" to "1 porción grande"),
        "Cena" to listOf("Restos del almuerzo o cena ligera" to "A gusto")
    )
)
