package com.appfitlife.appfitlife.ui.screens.routines

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.appfitlife.appfitlife.ui.theme.Primary
import com.appfitlife.appfitlife.viewmodel.ProfileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyRoutinesScreen(viewModel: ProfileViewModel, userId: String) {
    LaunchedEffect(userId) { viewModel.initializeUserProfile(userId) }
    val userProfileState by viewModel.userProfile.collectAsState()
    val routines = userProfileState.routines.groupBy { it.routine.name.substringBefore(" - ").trim() }

    Scaffold(topBar = { TopAppBar(title = { Text("Mis Rutinas") }) }) {
        LazyColumn(modifier = Modifier.padding(it).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (routines.isEmpty() && userProfileState.initialSetupDone) {
                item { Text("No tienes rutinas todavía. ¡Establece una meta en tu perfil para empezar!", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(32.dp)) }
            }
            routines.forEach { (day, routinesForDay) ->
                item { Text(day, style = MaterialTheme.typography.headlineMedium, color = Primary, modifier = Modifier.padding(vertical = 8.dp)) }
                items(routinesForDay) { routine ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(routine.routine.name.substringAfter(" - ").trim(), style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            routine.exercises.forEach { exercise ->
                                Text("\u2022 ${exercise.name}: ${exercise.reps}", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}