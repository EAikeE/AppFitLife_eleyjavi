package com.appfitlife.appfitlife.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.appfitlife.appfitlife.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.pow

data class UserProfileState(
    val user: User? = null,
    val routines: List<RoutineWithExercises> = emptyList(),
    val mealPlans: List<MealPlanWithFoods> = emptyList(),
    val initialSetupDone: Boolean = false
)

class ProfileViewModel(
    private val userRepository: UserRepository,
    private val routineDao: RoutineDao,
    private val mealPlanDao: MealPlanDao,
    application: Application
) : AndroidViewModel(application) {

    private val _userProfile = MutableStateFlow(UserProfileState())
    val userProfile: StateFlow<UserProfileState> = _userProfile.asStateFlow()

    fun initializeUserProfile(userId: String) {
        viewModelScope.launch {
            userRepository.getUserById(userId)?.let { user ->
                _userProfile.update { it.copy(user = user) }
                combine(
                    routineDao.getRoutinesForUser(user.id),
                    mealPlanDao.getMealPlansForUser(user.id)
                ) { routines, mealPlans ->
                    _userProfile.value.copy(
                        routines = routines,
                        mealPlans = mealPlans,
                        initialSetupDone = true
                    )
                }.onEach { state ->
                    _userProfile.value = state
                }.launchIn(viewModelScope)
            }
        }
    }

    fun calculateWeightGoalDate(currentWeight: Float, targetWeight: Float): String {
        if (currentWeight <= 0 || targetWeight <= 0) return ""
        val diff = kotlin.math.abs(currentWeight - targetWeight)
        if (diff < 0.5) return "Ya estás en tu peso objetivo."
        val weeks = kotlin.math.ceil(diff / 0.5).toInt()
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.WEEK_OF_YEAR, weeks)
        val date = calendar.time
        val formattedDate = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(date)
        
        val months = weeks / 4
        val remainingWeeks = weeks % 4
        val timeString = when {
            months > 0 && remainingWeeks > 0 -> "$months meses y $remainingWeeks semanas"
            months > 0 -> "$months meses"
            else -> "$weeks semanas"
        }
        
        return "Fecha estimada: $formattedDate (aprox. $timeString)."
    }

    fun setWeightGoalAndGeneratePlan(user: User, targetWeightKg: Float): String {
        val currentWeight = user.weight?.toFloat() ?: 0f
        if (currentWeight <= 0 || targetWeightKg <= 0) return "Por favor, introduce un peso válido."

        val goal = if (targetWeightKg < currentWeight) "loss" else "gain"

        viewModelScope.launch {
            val updatedUser = user.copy(targetWeight = targetWeightKg.toDouble())
            userRepository.updateUser(updatedUser)
            _userProfile.update { it.copy(user = updatedUser) }

            routineDao.deleteRoutinesForUser(user.id)
            mealPlanDao.deleteMealPlansForUser(user.id)
            generateWeeklyPlan(goal, user.id, updatedUser.excludedFoods ?: emptyList())
        }

        return ("¡Plan semanal generado para alcanzar %.1f kg!").format(targetWeightKg)
    }

    private suspend fun generateWeeklyPlan(goal: String, userId: String, excludedFoods: List<String>) {
        val days = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
        val routineMap = if (goal == "loss") getWeightLossRoutineMap() else getWeightGainRoutineMap()
        val allMealOptions = if (goal == "loss") getWeightLossMealMap() else getWeightGainMealMap()

        val filteredMealOptions = allMealOptions.mapValues { (_, dayMeals) ->
            dayMeals.mapValues { (_, mealFoods) ->
                mealFoods.filter { (foodName, _) ->
                    excludedFoods.none { excluded -> foodName.contains(excluded.trim(), ignoreCase = true) }
                }
            }.filter { (_, foods) -> foods.isNotEmpty() }
        }

        days.forEach { day ->
            routineMap[day]?.let { (routineName, exercises) ->
                val routineId = routineDao.insertRoutine(RoutineEntity(name = "$day - $routineName", userId = userId))
                exercises.forEach { (exerciseName, details) ->
                    routineDao.getAllExercises().first().find { it.name.equals(exerciseName, ignoreCase = true) }?.let { exercise ->
                        routineDao.insertRoutineExerciseCrossRef(RoutineExerciseCrossRef(routineId, exercise.exerciseId, details))
                    }
                }
            }

            filteredMealOptions[day]?.forEach { (mealType, foods) ->
                if (foods.isNotEmpty()) {
                    val planId = mealPlanDao.insertMealPlan(MealPlanEntity(name = "$day - $mealType", userId = userId))
                    foods.forEach { (foodName, details) ->
                        mealPlanDao.getAllFoodItems().first().find { it.name.equals(foodName, ignoreCase = true) }?.let { food ->
                            mealPlanDao.insertMealPlanFoodCrossRef(MealPlanFoodCrossRef(planId, food.foodItemId, details))
                        }
                    }
                }
            }
        }
    }

    fun updateUserName(newName: String) {
        _userProfile.value.user?.let {
            val updatedUser = it.copy(name = newName)
            viewModelScope.launch { userRepository.updateUser(updatedUser); _userProfile.update { it.copy(user = updatedUser) } }
        }
    }

    fun updateUserImage(imageUri: Uri) {
        _userProfile.value.user?.let {
            val updatedUser = it.copy(imageUri = imageUri.toString())
            viewModelScope.launch {
                userRepository.updateUser(updatedUser)
                _userProfile.update { it.copy(user = updatedUser) }
            }
        }
    }

    fun updateUserExcludedFoods(excludedFoods: List<String>) {
        val currentUser = _userProfile.value.user ?: return
        val updatedUser = currentUser.copy(excludedFoods = excludedFoods)

        viewModelScope.launch {
            userRepository.updateUser(updatedUser)
            updatedUser.targetWeight?.let { weight ->
                routineDao.deleteRoutinesForUser(updatedUser.id)
                mealPlanDao.deleteMealPlansForUser(updatedUser.id)
                val goal = if (weight.toFloat() < (updatedUser.weight ?: 0.0)) "loss" else "gain"
                generateWeeklyPlan(goal, updatedUser.id, updatedUser.excludedFoods ?: emptyList())
            }
            _userProfile.update {
                it.copy(user = updatedUser)
            }
        }
    }
    fun calculateBmiAndWeightGoal(weightKg: Float, heightCm: Float): BmiResult {
        if (heightCm <= 0 || weightKg <= 0) return BmiResult(0f, "Datos inválidos", "Por favor, asegúrate de que tu peso y altura sean correctos en tu perfil.")
        val heightM = heightCm / 100f
        val bmi = weightKg / (heightM * heightM)
        val category = when {
            bmi < 18.5 -> "Bajo peso"
            bmi < 25 -> "Peso saludable"
            bmi < 30 -> "Sobrepeso"
            else -> "Obesidad"
        }
        val idealMin = 18.5f * heightM.pow(2)
        val idealMax = 24.9f * heightM.pow(2)
        val goalMsg = when (category) {
            "Peso saludable" -> "¡Felicidades! Estás en tu peso ideal (entre %.1f kg y %.1f kg). Puedes enfocarte en mantener tu estilo de vida o tonificar.".format(idealMin, idealMax)
            "Bajo peso" -> "Tu IMC indica bajo peso. Tu rango de peso ideal está entre %.1f kg y %.1f kg. ¡Un plan de superávit calórico y fuerza te ayudará a ganar peso de forma saludable!".format(idealMin, idealMax)
            else -> "Tu IMC indica sobrepeso. Tu rango de peso ideal está entre %.1f kg y %.1f kg. Un buen primer objetivo sería llegar a %.1f kg.".format(idealMin, idealMax, idealMax)
        }
        return BmiResult(bmi, category, goalMsg)
    }
}