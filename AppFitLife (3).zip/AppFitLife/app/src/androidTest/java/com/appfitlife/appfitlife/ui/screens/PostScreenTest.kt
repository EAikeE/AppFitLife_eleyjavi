package com.appfitlife.appfitlife.ui.screens

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.appfitlife.appfitlife.data.model.Post
import com.appfitlife.appfitlife.repository.PostRepository
import com.appfitlife.appfitlife.viewmodel.PostViewModel
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.flow.MutableStateFlow
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PostScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun postScreen_displaysPosts_whenLoaded() {
        // Given
        val repository = mockk<PostRepository>()
        val posts = listOf(
            Post(1, 1, "Title 1", "Body 1"),
            Post(2, 2, "Title 2", "Body 2")
        )
        coEvery { repository.getPosts() } returns posts
        val viewModel = PostViewModel(repository)

        // When
        composeTestRule.setContent {
            PostScreen(postViewModel = viewModel)
        }

        // Then
        composeTestRule.onNodeWithText("Title 1").assertIsDisplayed()
        composeTestRule.onNodeWithText("Body 1").assertIsDisplayed()
        composeTestRule.onNodeWithText("Title 2").assertIsDisplayed()
        composeTestRule.onNodeWithText("Body 2").assertIsDisplayed()
    }

    @Test
    fun postScreen_showsEmptyMessage_whenNoPosts() {
        // Given
        val repository = mockk<PostRepository>()
        coEvery { repository.getPosts() } returns emptyList()
        val viewModel = PostViewModel(repository)

        // When
        composeTestRule.setContent {
            PostScreen(postViewModel = viewModel)
        }

        // Then
        // El LazyColumn estará vacío, así que no se mostrará ningún post.
        // Podríamos añadir un Text() en la UI para este caso, pero por ahora
        // nos aseguramos de que no crashee y no muestre ningún post.
        composeTestRule.onNodeWithText("Title 1").assertDoesNotExist()
    }
}